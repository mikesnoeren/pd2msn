-- MySQL dump 10.13  Distrib 8.0.19, for Linux (x86_64)
--
-- Host: localhost    Database: lamp
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `administrativeArea` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `locality` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dependentLocality` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `postalCode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortingCode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `addressLine1` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `addressLine2` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `organization` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `organizationTaxId` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_yqydclcnukgpbtvzreimsfziatvbwrwavdzr` (`ownerId`),
  CONSTRAINT `fk_mdydxrhmarpiibmqyaevxdwysiamqmwpjipc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yqydclcnukgpbtvzreimsfziatvbwrwavdzr` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sjwgtlntxgogckodouvlkwsxpqqyxaceglma` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_wlutjuaiitvueuuxihrweuuqaqpmgfltzwzp` (`dateRead`),
  KEY `fk_gpahwrxcowfxgczpnguvzqdabcrrqhrxkpyw` (`pluginId`),
  CONSTRAINT `fk_gpahwrxcowfxgczpnguvzqdabcrrqhrxkpyw` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_irbuiqvkxopyagugvyhaldfkshhdushpsnbl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yxupusxlypsbmpbhchjblwktarwnglxqcjkr` (`volumeId`),
  KEY `idx_terccekpfbjqmsrijsviljzismjzqcrigmsx` (`volumeId`),
  KEY `fk_hfmwusorlblmlgribwyidztdvddrctqfphsb` (`sessionId`),
  CONSTRAINT `fk_bwngnpqwwihahcfqrjuzbvvqhzzhwozpnnsi` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hfmwusorlblmlgribwyidztdvddrctqfphsb` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `kind` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `alt` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bqaifkslotwupzswsmxcoguyxjoudyjjlhpo` (`filename`,`folderId`),
  KEY `idx_pvvcbqfihixjavcuzzduevjxnfdnyizjvrtm` (`folderId`),
  KEY `idx_uvutoybfidpktpysbxqujrwbdamgivrvwend` (`volumeId`),
  KEY `fk_ektrxxfnffzvbouaxejnipxykoszfiuheyzn` (`uploaderId`),
  CONSTRAINT `fk_dlygupegtfqymhjndvizrhemeybjhstlhiut` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_efeskjyvqprgmgzzahjrsxrvugjzmqmumxjx` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ektrxxfnffzvbouaxejnipxykoszfiuheyzn` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oicvbiqhebvwkjyokyceycjglnqhgpdufbin` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_awdvqgvrffhxrmlwixdqyuzwvikrwaegncxa` (`groupId`),
  KEY `fk_jlfrorrdutomjxbvsmybqqarzhdrgohftjuz` (`parentId`),
  CONSTRAINT `fk_jlfrorrdutomjxbvsmybqqarzhdrgohftjuz` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lagkatyiaagsnittumtwqjpbizqdtkpejfhz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_quvwbaevfuncqmlpvvdsxsahpkwltbqrcdyu` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (41,1,NULL,NULL,'2022-05-13 17:59:58','2022-05-13 17:59:58'),(42,1,NULL,NULL,'2022-05-13 18:00:36','2022-05-13 18:00:36'),(43,1,NULL,NULL,'2022-05-13 18:00:46','2022-05-13 18:00:46'),(44,1,NULL,NULL,'2022-05-13 18:00:57','2022-05-13 18:00:57'),(45,1,NULL,NULL,'2022-05-13 18:01:11','2022-05-13 18:01:11'),(46,1,NULL,0,'2022-05-13 18:01:21','2022-05-13 18:01:21'),(47,1,NULL,NULL,'2022-05-13 18:01:38','2022-05-13 18:01:38');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `defaultPlacement` enum('beginning','end') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uqrodogmmfxozvuxwspgrshxokpgsgujadfg` (`name`),
  KEY `idx_fprjpmewpmmzezmydlsktqgzjxtykxnlclku` (`handle`),
  KEY `idx_fvhbmpctxmrvixwiqydqgrwzevxjvjepbcre` (`structureId`),
  KEY `idx_pghrhfvkopryhvwgiieiibwmhmxilevdpwsh` (`fieldLayoutId`),
  KEY `idx_bwqvfmqtpqscjixjvmbxwsiwqyesddlzlwuk` (`dateDeleted`),
  CONSTRAINT `fk_jpbpqyemrqihjupzeerppegppumvdidsrpxk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zfazyvvfnwqyfobdnhpakwlscnteqwzzsvcu` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
INSERT INTO `categorygroups` VALUES (1,1,1,'Blog Categories','blogCategories','end','2022-02-14 21:25:34','2022-02-14 21:25:34',NULL,'541a135e-c132-4a7f-b2ef-9869b60caba3');
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `template` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rrauznopywsrlfaqssucaryozmtxwsxiyvyh` (`groupId`,`siteId`),
  KEY `idx_ryxxfwcsmgrowovocpbrpmkuljkpzxiygnan` (`siteId`),
  CONSTRAINT `fk_pyhmzzcmjbnocqvtulljkcjhmummumtelben` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zqawmluydnedjuuykpprawmrurydppcvowtn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
INSERT INTO `categorygroups_sites` VALUES (1,1,1,0,NULL,NULL,'2022-02-14 21:25:34','2022-02-14 21:25:34','312bfa87-c422-40e4-87a8-7b268f57cdb0'),(2,1,2,0,NULL,NULL,'2022-02-14 21:25:34','2022-02-14 21:25:34','445fe492-61fc-4048-ac89-e24398911ae5');
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_wkagmgpwpejzwknnueedkfabweejgmkzhhju` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_mvqstxuwrtsxohbbjkkypwwzmwxuymejzgus` (`siteId`),
  KEY `fk_spkolnpccmfosgfucbgrdcfqbqsfyhfwxbjs` (`userId`),
  CONSTRAINT `fk_aykmtutcywkzejxirlolhkwoxskmwcinubbv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mvqstxuwrtsxohbbjkkypwwzmwxuymejzgus` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_spkolnpccmfosgfucbgrdcfqbqsfyhfwxbjs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (8,1,'fullName','2022-05-13 18:03:30',0,8),(15,1,'slug','2022-05-12 17:54:52',0,8),(15,1,'title','2022-05-12 17:39:14',0,8),(15,1,'uri','2022-05-12 17:40:32',0,8),(15,2,'slug','2022-05-12 17:54:52',1,8),(15,2,'title','2022-05-12 17:39:38',0,8),(15,2,'uri','2022-05-12 17:40:32',1,8),(32,1,'postDate','2022-05-12 17:45:57',1,8),(32,1,'slug','2022-05-22 13:13:58',0,8),(32,1,'title','2022-05-12 17:45:52',1,8),(32,1,'uri','2022-05-22 13:13:55',0,8),(32,2,'postDate','2022-05-12 17:45:57',0,8),(32,2,'slug','2022-05-22 13:13:58',1,8),(32,2,'title','2022-05-12 17:45:52',0,8),(32,2,'uri','2022-05-22 13:13:55',1,8);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_qrkqkqprqkossbtilvttgosnclkkqxxzkegs` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_rqwivnkpiepkwlululelcctvbimdzwnaijtq` (`siteId`),
  KEY `fk_znujwneqdkzjizrthjgejtmhdrqmxdrsizne` (`fieldId`),
  KEY `fk_lfrdbwswygptweyufziyatcrikhydijpiisw` (`userId`),
  CONSTRAINT `fk_hmktvbokomaqrothkzntmzykwlehdidbvbcs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lfrdbwswygptweyufziyatcrikhydijpiisw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_rqwivnkpiepkwlululelcctvbimdzwnaijtq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_znujwneqdkzjizrthjgejtmhdrqmxdrsizne` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (11,1,3,'2022-05-12 18:14:43',0,8),(11,2,3,'2022-05-12 18:14:43',1,8),(15,1,3,'2022-05-12 17:57:33',0,8),(15,2,3,'2022-05-12 17:57:33',1,8),(32,1,3,'2022-05-22 13:13:55',0,8),(32,1,9,'2022-05-22 13:13:58',0,8),(32,2,3,'2022-05-22 13:13:58',1,8),(32,2,9,'2022-05-22 13:14:00',0,8),(52,1,5,'2022-05-16 07:45:37',0,8);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `field_seo_xicqkdxc` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `field_blogCategoryColor_ayvjetxk` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qwhqqzccpwhswmfuncclaetmkmfmwggdstdb` (`elementId`,`siteId`),
  KEY `idx_zbqtjwuhtvblsxhdbnolesejdwxrkxuvbtfi` (`siteId`),
  KEY `idx_zvvnonwcvyttlocirrnrxadcmkpgzcnebzvf` (`title`),
  CONSTRAINT `fk_cwdpojwodsjeorjknacyaidglovfcsthcwkb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dwbbzwyoulazizffumwtrxrweqjhusgcpzec` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2022-02-14 21:25:35','2022-02-14 21:25:36','4dc39c9e-e646-48ac-a37c-e252700d8f00',NULL,NULL),(2,1,2,NULL,'2022-02-14 21:25:35','2022-02-14 21:25:36','afceb3a7-f8ce-4e22-8d06-9d365e1f9589',NULL,NULL),(3,2,1,'Blog Overview','2022-02-14 21:25:35','2022-02-14 21:25:35','326948f6-c4b4-4843-be8c-05d01f9bcd3c','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(4,2,2,'Blog Overview','2022-02-14 21:25:35','2022-02-14 21:25:35','3155fad4-8674-4ae9-b101-1a0d793dcd6c','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(5,3,1,'Blog Overview','2022-02-14 21:25:35','2022-02-14 21:25:35','04b9e86c-9bbe-4389-accc-fa316faf45ab','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(6,3,2,'Blog Overview','2022-02-14 21:25:35','2022-02-14 21:25:35','d8c994dc-6c5c-489f-9d58-e37ea4e126be','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Blog Overview - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(7,4,1,'Contact','2022-02-14 21:25:35','2022-02-14 21:25:35','181e3715-f536-4e1e-9a51-78f6ecbed1a3','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(8,4,2,'Contact','2022-02-14 21:25:35','2022-02-14 21:25:35','6280bbd7-93af-4045-a310-c5e9fb1f5b7a','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(9,5,1,'Contact','2022-02-14 21:25:35','2022-02-14 21:25:35','eba39dbe-3146-4947-b2c9-a761f9e4ba5b','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(10,5,2,'Contact','2022-02-14 21:25:35','2022-02-14 21:25:35','9aaaf804-4e3d-419f-aa5d-b187e0ef6419','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(11,6,1,'Home','2022-02-14 21:25:35','2022-04-29 18:41:55','ce01a3c2-50e9-41ad-8025-ccb9c294b2c2','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(12,6,2,'Home','2022-02-14 21:25:35','2022-04-29 18:41:55','65f5aaf4-048b-404a-b8dc-941687d81dae','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(13,7,1,'Home','2022-02-14 21:25:35','2022-02-14 21:25:35','7fdbaeb7-3166-4e55-aff8-c4f4940007f2','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(14,7,2,'Home','2022-02-14 21:25:35','2022-02-14 21:25:35','b7c1bb66-7eeb-4043-88d7-1025b5002b53','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":null,\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(15,8,1,NULL,'2022-02-14 21:25:36','2022-05-13 18:03:30','c20024a3-1f7f-48bd-a1f4-b943c20e9f28',NULL,NULL),(16,9,1,'Home','2022-04-29 18:41:54','2022-04-29 18:41:54','27c931a1-1a69-4342-9d98-9d8f761a60cc','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(17,9,2,'Home','2022-04-29 18:41:55','2022-04-29 18:41:55','b03d54dc-ec56-42e6-876e-365e0604df10','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(18,10,1,'Home','2022-04-29 18:41:55','2022-04-29 18:41:55','bfbf3919-9b8c-4ac7-aae1-1c2971178afa','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(19,10,2,'Home','2022-04-29 18:41:55','2022-04-29 18:41:55','a91a629f-cf43-41f9-9893-da6d4a6c725d','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Home - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(20,11,1,'Contact','2022-04-29 18:43:18','2022-05-12 18:14:43','f7d183c0-88ef-472a-8df4-cca358d958c8','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(21,11,2,'Contact','2022-04-29 18:43:18','2022-05-12 18:14:43','7620ac2a-7324-4f41-b0bd-d64900b502aa','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(22,12,1,'Contact','2022-04-29 18:43:18','2022-04-29 18:43:18','32ddd03f-ae01-47c3-a253-8255e247228d',NULL,NULL),(23,12,2,'Contact','2022-04-29 18:43:18','2022-04-29 18:43:18','6bd589a9-6d90-4c1a-81e8-3377ab69b3b4',NULL,NULL),(24,13,1,'Contact','2022-04-29 18:43:19','2022-04-29 18:43:19','ccc7e24f-1a56-43fa-a7b3-dc79fe8172b7',NULL,NULL),(25,13,2,'Contact','2022-04-29 18:43:19','2022-04-29 18:43:19','9a35c2be-e942-402b-92e4-d1be8d4063f8',NULL,NULL),(26,14,1,'Contact','2022-04-29 18:47:37','2022-04-29 18:47:37','3598b1fb-1a43-44ae-b410-7c7888c2dc41',NULL,NULL),(27,14,2,'Contact','2022-04-29 18:47:37','2022-04-29 18:47:37','ec2a90d3-f670-4336-af8a-4672c7c7356c',NULL,NULL),(28,15,1,'Blog','2022-04-29 20:00:58','2022-05-13 19:34:13','882cdf11-5ef6-4d9d-b9b3-69075edce0ef','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(29,15,2,'Blog','2022-04-29 20:00:58','2022-05-13 19:34:13','9f0941d5-314a-4531-9e9c-bf6caf5d7163','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(36,19,1,'Contact','2022-05-12 17:36:09','2022-05-12 17:36:09','314682d9-7f63-4ef3-aff0-69795edc76da','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(37,19,2,'Contact','2022-05-12 17:36:09','2022-05-12 17:36:09','932a1670-7f9a-472f-a354-68a1ff63ff12','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(38,20,1,'Contact','2022-05-12 17:36:10','2022-05-12 17:36:10','62aa1ee3-9a9e-4623-a0a0-706261caf1fd','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(39,20,2,'Contact','2022-05-12 17:36:10','2022-05-12 17:36:10','5a33aa75-3c56-498c-a496-9a837a1c1d99','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(54,28,1,'Blog','2022-05-12 17:45:04','2022-05-12 17:45:04','7bd37e5e-86c9-41b6-abc6-2d776893e692','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(55,28,2,'Blog','2022-05-12 17:45:05','2022-05-12 17:45:05','8e74d0ab-567f-4d58-92ad-b176169b078f','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(56,29,1,'Blog','2022-05-12 17:45:05','2022-05-12 17:45:05','fbb22387-a239-4328-ba4a-42b2a259fde4','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(57,29,2,'Blog','2022-05-12 17:45:05','2022-05-12 17:45:05','a5e81487-c149-4c00-9431-def0342658a4','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(58,30,1,'Blog','2022-05-12 17:45:34','2022-05-12 17:45:34','954ac80a-5ffa-43ac-a33f-df49dc3c808f','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(59,30,2,'Blog','2022-05-12 17:45:35','2022-05-12 17:45:35','0df8837a-3db0-43cc-9f93-dc1869cf306b','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(60,31,1,'Blog','2022-05-12 17:45:35','2022-05-12 17:45:35','095537ca-c629-4513-992c-8dfdcb9a37ae','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(61,31,2,'Blog','2022-05-12 17:45:35','2022-05-12 17:45:35','7a753535-2cee-40df-892d-73016672ef01','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(62,32,2,'test','2022-05-12 17:45:48','2022-05-22 13:20:48','de14756f-75ae-479f-b025-5d55e5375a56','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(63,32,1,'test','2022-05-12 17:45:48','2022-05-22 13:20:48','a8f8a863-dd45-4d82-a3a3-a726cb8ab7b0','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(64,33,2,'test','2022-05-12 17:45:57','2022-05-12 17:45:57','d4b4a4e5-7f75-415d-9aeb-f38009b5b09a','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(65,33,1,'test','2022-05-12 17:45:58','2022-05-12 17:45:58','eb92384d-a465-4f7e-892d-a3e4621766f6','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(68,35,1,'Blog','2022-05-12 17:54:52','2022-05-12 17:54:52','c459e1c0-a337-4f11-ac9c-711228680026','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(69,35,2,'Blog','2022-05-12 17:54:52','2022-05-12 17:54:52','e5945690-1fbc-452a-b23f-a1888a0718f1','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(70,36,1,'Blog','2022-05-12 17:57:29','2022-05-12 17:57:29','127cecf7-2d3f-4795-ab94-bbf875bcdaca','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(71,36,2,'Blog','2022-05-12 17:57:29','2022-05-12 17:57:29','3c914110-0c98-4061-9e9c-188406595759','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(72,37,1,'Blog','2022-05-12 17:57:30','2022-05-12 17:57:30','bbdf7a08-f621-4d7a-8d28-c7e15f9b8cee','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(73,37,2,'Blog','2022-05-12 17:57:30','2022-05-12 17:57:30','a6730637-0cb6-4d42-b090-836eb9e418e0','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(74,38,1,'Blog','2022-05-12 17:58:25','2022-05-12 17:58:25','be13fd86-4793-4749-9808-0346ad496df4','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(75,38,2,'Blog','2022-05-12 17:58:25','2022-05-12 17:58:25','6d339ebe-6654-45a2-87dc-074e174be106','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(76,39,2,'Blog','2022-05-12 17:58:31','2022-05-12 17:58:31','dc2cf8b4-b39e-4931-9073-398f9c9c54c6','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(77,39,1,'Blog','2022-05-12 17:58:31','2022-05-12 17:58:31','3e97e58b-a2e0-42e3-976e-2bc79af8145f','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(78,40,1,'Contact','2022-05-12 18:14:40','2022-05-12 18:14:40','b7117afa-df9b-40f5-9785-a110840776cf','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(79,40,2,'Contact','2022-05-12 18:14:40','2022-05-12 18:14:40','6d42b10c-08f9-4197-9d3c-e60a8ee531a2','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Contact - PD2MSN\",\"imageId\":null,\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":null}}',NULL),(80,41,1,'Red','2022-05-13 17:59:58','2022-05-13 18:00:35','e5c41869-64bf-4d79-a451-d2daba7c3dc1',NULL,'red'),(81,41,2,'Red','2022-05-13 17:59:59','2022-05-13 18:00:35','0e9f46c6-ce9d-4391-9191-f9a1900d1105',NULL,'red'),(82,42,1,'Orange','2022-05-13 18:00:36','2022-05-13 18:00:45','5114ebff-01a0-4efc-9b25-08521a3b93d2',NULL,'orange'),(83,42,2,NULL,'2022-05-13 18:00:36','2022-05-13 18:00:45','d2de264e-fb54-4878-8b8b-ee111015c81d',NULL,'orange'),(84,43,1,'Green','2022-05-13 18:00:46','2022-05-13 18:00:57','1ca3d8a2-5be1-40ab-8608-49e184fd09a1',NULL,'green'),(85,43,2,NULL,'2022-05-13 18:00:46','2022-05-13 18:00:57','5684367e-be14-4ab5-be5b-2876198ca7f0',NULL,'green'),(86,44,1,'Blue','2022-05-13 18:00:57','2022-05-13 18:01:10','67ee2dff-ebca-4910-9962-062ebf7745ea',NULL,'blue'),(87,44,2,NULL,'2022-05-13 18:00:58','2022-05-13 18:01:10','bb42e777-cc42-42a5-b005-ccf4ce1b0b00',NULL,'blue'),(88,45,1,'Purple','2022-05-13 18:01:11','2022-05-13 18:01:21','3ecfb369-7d7d-4e0e-b821-551b8c036d65',NULL,'purple'),(89,45,2,NULL,'2022-05-13 18:01:11','2022-05-13 18:01:21','360b1022-3bc7-442d-845e-8e0695f91335',NULL,'purple'),(90,46,1,'Purple','2022-05-13 18:01:21','2022-05-13 18:01:37','2208233b-4c9f-4ea2-b29c-c7ae01999965',NULL,'purple'),(91,46,2,NULL,'2022-05-13 18:01:22','2022-05-13 18:01:37','47008532-286f-49d1-b306-c55eff62077f',NULL,'purple'),(92,47,1,'Pink','2022-05-13 18:01:38','2022-05-13 18:01:48','6251f341-063a-4f0d-a30e-4bbca6dcc51f',NULL,'pink'),(93,47,2,NULL,'2022-05-13 18:01:38','2022-05-13 18:01:48','479752cb-b309-42ad-b42f-b1352e8ad846',NULL,'pink'),(94,48,1,'Blog','2022-05-13 19:34:13','2022-05-13 19:34:13','60c60b86-84e5-45c5-9428-ad999d252e58','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(95,48,2,'Blog','2022-05-13 19:34:13','2022-05-13 19:34:13','5b89ba04-5bce-43fd-97fe-ac26dce67c3b','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(98,52,1,'Blog','2022-05-16 07:45:34','2022-05-16 07:45:36','c11b2da7-6b1a-484f-9c32-51f3e3d6ec57','{\"titleRaw\":{\"1\":\"Blog\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(99,52,2,'Blog','2022-05-16 07:45:34','2022-05-16 07:45:36','24a1aac8-8ddc-4128-884c-b01e81343672','{\"titleRaw\":{\"1\":\"Blog Overview\"},\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"Blog - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(102,55,1,'test','2022-05-22 13:13:57','2022-05-22 13:13:57','527d1e51-c57b-4728-8488-ba1e4103a578','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(103,55,2,'test','2022-05-22 13:13:57','2022-05-22 13:13:57','1cbb2495-d0d6-4a4e-92c1-937cd99092fc','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(104,56,1,'test','2022-05-22 13:20:48','2022-05-22 13:20:48','622bff53-2e6e-425e-b0fa-18d8d715b73c','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL),(105,56,2,'test','2022-05-22 13:20:48','2022-05-22 13:20:48','5cc553ff-344c-4f29-a1ac-85f387ddd338','{\"titleRaw\":[],\"descriptionRaw\":\"\",\"keywords\":[],\"score\":\"neutral\",\"social\":{\"twitter\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"},\"facebook\":{\"handle\":\"\",\"title\":\"test - PD2MSN\",\"imageId\":\"\",\"description\":\"\"}},\"advanced\":{\"robots\":[],\"canonical\":\"\"}}',NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_gdqofgenadinowlxjphxzorlfmwmynjuhsac` (`userId`),
  CONSTRAINT `fk_gdqofgenadinowlxjphxzorlfmwmynjuhsac` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `traces` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mraqjjhdbynmslrjykqwsjkoqohvnujzegrx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `notes` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_pxukjpkuyrkcjywqztjygggwutjjchauoagy` (`creatorId`,`provisional`),
  KEY `idx_ffhjjbijxgcdlhwbqrztvdubboqeweqqqyzf` (`saved`),
  KEY `fk_pkkqazhvajttooauqcncybyzkgplcphcquxi` (`canonicalId`),
  CONSTRAINT `fk_jmxfpvporqykoagkknbtddyrnxfiwehbavey` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pkkqazhvajttooauqcncybyzkgplcphcquxi` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (14,15,8,1,'Draft 1','',1,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kbycjlmlfrpjoobxursbmavtvgvuuncrwoce` (`dateDeleted`),
  KEY `idx_sfulorrrrkalvvllyyhtaazrkuyporqjfxrv` (`fieldLayoutId`),
  KEY `idx_yxwzwbgzmyzcoenzaompthlmymqrwtmfuajh` (`type`),
  KEY `idx_fsuqmefqjxzeftmtoeclrbbqxgqpgnjbpgzt` (`enabled`),
  KEY `idx_lpsfmewcerajjaiqqafaocsdhyvtrgglsqtb` (`archived`,`dateCreated`),
  KEY `idx_ivvuxsshvhogkekeipqzonqipieookjeprpt` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `fk_crxiqjfnendugeinjwkovsymwkfjkgyxvikl` (`canonicalId`),
  KEY `fk_vujbddytgybiiiqbxdohhcvwxzluneuisplb` (`draftId`),
  KEY `fk_lvxuldgyzvtlfcaliosubcdeuycfotoynayo` (`revisionId`),
  KEY `idx_cqcxccsgavgpkcgheoqgkrnapjwppdrtlasc` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  CONSTRAINT `fk_azkwlhoqrdneeojzetpnqmramuojcixeooog` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_crxiqjfnendugeinjwkovsymwkfjkgyxvikl` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lvxuldgyzvtlfcaliosubcdeuycfotoynayo` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vujbddytgybiiiqbxdohhcvwxzluneuisplb` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,2,'craft\\elements\\GlobalSet',1,0,'2022-02-14 21:25:35','2022-02-14 21:25:36',NULL,NULL,'2d0fb778-2d78-49c0-b94d-740200560f8f'),(2,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'2022-04-29 18:40:41','e9836bb9-49d4-466e-9752-a46c1ff1b6ac'),(3,2,NULL,1,5,'craft\\elements\\Entry',1,0,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'2022-04-29 18:40:41','1a64e05c-b360-4bd8-b3ca-46a926c4b12d'),(4,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'2022-04-29 18:40:47','d42160ca-c89f-43db-aeb3-c0c1fbfa9584'),(5,4,NULL,2,6,'craft\\elements\\Entry',1,0,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'2022-04-29 18:40:47','f608ea7e-bd58-4d6a-a251-6549454bd660'),(6,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2022-02-14 21:25:35','2022-04-29 18:41:55',NULL,NULL,'5e400f74-4a4a-44ae-8e66-c9849aaa2d87'),(7,6,NULL,3,7,'craft\\elements\\Entry',1,0,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,NULL,'69aebcab-db75-486f-bbc5-13005e5018aa'),(8,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2022-02-14 21:25:36','2022-05-13 18:03:29',NULL,NULL,'4aa584b7-4a4b-45a3-b31d-0ce4339facea'),(9,6,NULL,4,7,'craft\\elements\\Entry',1,0,'2022-04-29 18:41:54','2022-04-29 18:41:54',NULL,NULL,'27995027-9eee-42ee-9bc9-0bd05b7f337f'),(10,6,NULL,5,7,'craft\\elements\\Entry',1,0,'2022-04-29 18:41:55','2022-04-29 18:41:55',NULL,NULL,'42ffd841-0eb5-42db-b3c0-90ad521a20f6'),(11,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2022-04-29 18:43:18','2022-05-12 18:14:40',NULL,NULL,'ea501184-48af-404e-9158-6a0e6ccbc546'),(12,11,NULL,6,9,'craft\\elements\\Entry',1,0,'2022-04-29 18:43:18','2022-04-29 18:43:18',NULL,NULL,'15296562-2e88-4455-b84a-c6d24fe7a1c0'),(13,11,NULL,7,9,'craft\\elements\\Entry',1,0,'2022-04-29 18:43:19','2022-04-29 18:43:19',NULL,NULL,'8e4f23a2-1209-46b2-b06c-5bb37605f5b4'),(14,11,NULL,8,9,'craft\\elements\\Entry',1,0,'2022-04-29 18:47:36','2022-04-29 18:47:37',NULL,NULL,'7b86bd3e-c117-47c4-a072-d7aa29ec83dc'),(15,NULL,NULL,NULL,11,'craft\\elements\\Entry',1,0,'2022-04-29 20:00:58','2022-05-13 19:34:12',NULL,NULL,'552432f2-cf76-4725-9a8f-537b3f317784'),(19,11,NULL,12,9,'craft\\elements\\Entry',1,0,'2022-05-12 17:36:09','2022-05-12 17:36:09',NULL,NULL,'8a4c64bb-a802-4995-9a34-a4bd309b99ef'),(20,11,NULL,13,9,'craft\\elements\\Entry',1,0,'2022-05-12 17:36:10','2022-05-12 17:36:10',NULL,NULL,'10a42b8c-3972-4e31-a9b0-afabb3dda582'),(28,15,NULL,18,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:45:04','2022-05-12 17:45:04',NULL,NULL,'f7c0689e-3336-4098-8660-8e40e332e718'),(29,15,NULL,19,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:45:05','2022-05-12 17:45:05',NULL,NULL,'a00290b2-3a2c-4d2a-8496-391488c87fd3'),(30,15,NULL,20,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:45:34','2022-05-12 17:45:34',NULL,NULL,'9e308ee2-2da6-4493-b8c8-378bc313ffea'),(31,15,NULL,21,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:45:35','2022-05-12 17:45:35',NULL,NULL,'ce77cafb-1b9d-453c-9c9a-761316ffea5f'),(32,NULL,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2022-05-12 17:45:48','2022-05-22 13:20:48',NULL,NULL,'adfe5553-902c-418d-b4a8-f7b24a335ee5'),(33,32,NULL,22,10,'craft\\elements\\Entry',1,0,'2022-05-12 17:45:57','2022-05-12 17:45:57',NULL,NULL,'8adf9566-0e6c-48e9-b370-450098bdb50f'),(35,15,NULL,23,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:54:52','2022-05-12 17:54:52',NULL,NULL,'5ac8f338-09f4-4ccd-a3e3-ab8e0bf5dad5'),(36,15,NULL,24,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:57:29','2022-05-12 17:57:29',NULL,NULL,'a40dd55e-625c-4476-aac7-cbeaaf602b77'),(37,15,NULL,25,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:57:30','2022-05-12 17:57:30',NULL,NULL,'4f50e91f-9c2e-4326-b790-2820c8102651'),(38,15,NULL,26,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:58:25','2022-05-12 17:58:25',NULL,NULL,'97b1390e-af18-4a62-845e-7fd31b6f0bbf'),(39,15,NULL,27,11,'craft\\elements\\Entry',1,0,'2022-05-12 17:58:31','2022-05-12 17:58:31',NULL,NULL,'a1236690-cc1d-46e2-abf1-e47f4f55adb6'),(40,11,NULL,28,9,'craft\\elements\\Entry',1,0,'2022-05-12 18:14:40','2022-05-12 18:14:40',NULL,NULL,'da9845cb-b7f5-4e7f-a28d-1f18fdd137a5'),(41,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2022-05-13 17:59:58','2022-05-13 18:00:35',NULL,NULL,'b85edf53-c954-496a-a49b-190493b86bd2'),(42,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2022-05-13 18:00:36','2022-05-13 18:00:45',NULL,NULL,'5c5e7df1-c5f3-42e0-a7d7-1cc1275bbf43'),(43,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2022-05-13 18:00:46','2022-05-13 18:00:56',NULL,NULL,'08f3d636-993f-4d48-a60d-c7697f36e62d'),(44,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2022-05-13 18:00:57','2022-05-13 18:01:10',NULL,NULL,'e6d30010-7e4f-4da9-a753-ff4392123487'),(45,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2022-05-13 18:01:11','2022-05-13 18:01:21',NULL,NULL,'2eed10d6-4e2f-4113-9a8a-009bb51eeb05'),(46,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2022-05-13 18:01:21','2022-05-13 18:01:37',NULL,'2022-05-13 18:02:01','c31b526e-2d83-448c-8022-dcd5dc7aa552'),(47,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2022-05-13 18:01:38','2022-05-13 18:01:48',NULL,NULL,'24747720-10ee-41f7-a0a5-870bc99c3fe0'),(48,15,NULL,29,11,'craft\\elements\\Entry',1,0,'2022-05-13 19:34:12','2022-05-13 19:34:13',NULL,NULL,'174955e2-315e-4b54-84d2-218ca70855ef'),(50,NULL,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2022-05-16 07:06:16','2022-05-16 07:06:16',NULL,'2022-05-16 07:06:28','a23d74fb-60f5-43a3-95b1-5cedc7a18d69'),(51,NULL,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2022-05-16 07:06:40','2022-05-16 07:06:40',NULL,'2022-05-16 07:06:45','c12e649a-76bf-4245-9df8-e5af3a5eca93'),(52,15,14,NULL,11,'craft\\elements\\Entry',1,0,'2022-05-16 07:45:34','2022-05-16 07:45:36',NULL,NULL,'531493ac-2149-4425-80b1-e988c9f5db11'),(53,NULL,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2022-05-16 07:45:34','2022-05-16 07:45:34',NULL,'2022-05-16 07:45:36','603bfda6-4c79-441f-afc3-1a3bf0802327'),(55,32,NULL,30,10,'craft\\elements\\Entry',1,0,'2022-05-22 13:13:56','2022-05-22 13:13:57',NULL,NULL,'fa4e330c-11a3-40aa-9b3b-9b29484cb717'),(56,32,NULL,31,10,'craft\\elements\\Entry',1,0,'2022-05-22 13:20:48','2022-05-22 13:20:48',NULL,NULL,'4f09e812-4f0e-4f52-8f4c-61f6195b163d');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_czinellfdmmsheyewrpzgslhlczkjuelpobj` (`elementId`,`siteId`),
  KEY `idx_fhctecjhybbemokhexuvvtuifksrypnepieg` (`siteId`),
  KEY `idx_aksmuzfgdnzhqxdstwzjzigrctympluddqyt` (`slug`,`siteId`),
  KEY `idx_ckrnppqlkqrnkyxebliqkiebfgpveksoicqi` (`enabled`),
  KEY `idx_clbtdnqqaoottqncgotcotvgcidnwzgvnaxg` (`uri`,`siteId`),
  CONSTRAINT `fk_tqpptsqmgejorbolqceyieqvkihlqwhaxknu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vzmokrwixbpbbzlkqgnoeugjqciovwcjztrt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2022-02-14 21:25:35','2022-02-14 21:25:35','e4a3c04b-85c4-44f3-8d64-cacea36db0ed'),(2,1,2,NULL,NULL,1,'2022-02-14 21:25:35','2022-02-14 21:25:35','6f2ec7a5-30b1-4b46-b641-a1bad56b8eb0'),(3,2,1,'blog-overview','blog',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','424f519a-c5a1-465d-b0a2-30f43add6958'),(4,2,2,'blog-overview','blog',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','891a18e1-40b6-42df-8311-cbd9a3c40fa5'),(5,3,1,'blog-overview','blog',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','3e01a1eb-892b-415d-93a8-3ab962509497'),(6,3,2,'blog-overview','blog',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','3928bdfe-5f39-4b56-86ec-6941e64265cc'),(7,4,1,'contact','contact',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','711858c1-848a-4dbd-b1b2-09bad0ca2360'),(8,4,2,'contact','contact',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','b0316de0-ac0b-4597-871e-a7a6ad9228e3'),(9,5,1,'contact','contact',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','a1f4caca-7d37-454c-a6d1-80c49396ad0c'),(10,5,2,'contact','contact',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','fdc62e4d-e755-41a4-ba42-39a1621b343a'),(11,6,1,'home','__home__',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','c6d5bc71-b585-496d-be33-145f6e941f5d'),(12,6,2,'home','__home__',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','737df119-e5b4-4130-afdc-6dad57ad7b70'),(13,7,1,'home','__home__',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','ff8714d1-71f6-41fa-beaa-36390ec1c85b'),(14,7,2,'home','__home__',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','b8eb349d-b93e-4277-a74f-41e14e22f8d0'),(15,8,1,NULL,NULL,1,'2022-02-14 21:25:36','2022-02-14 21:25:36','8adcca36-5009-4d9b-ab05-77acc711ad20'),(16,9,1,'home','__home__',1,'2022-04-29 18:41:54','2022-04-29 18:41:54','53ba6848-e15d-4b7c-bb1c-5da01b841cd2'),(17,9,2,'home','__home__',1,'2022-04-29 18:41:55','2022-04-29 18:41:55','77368e4b-951b-4ef6-8e78-ddae800aac06'),(18,10,1,'home','__home__',1,'2022-04-29 18:41:55','2022-04-29 18:41:55','bf7ade8c-7a21-4df6-a048-5297c88f6a85'),(19,10,2,'home','__home__',1,'2022-04-29 18:41:55','2022-04-29 18:41:55','b504e02d-a024-4c06-b3b1-e45758e156d8'),(20,11,1,'contact','contact',1,'2022-04-29 18:43:18','2022-04-29 18:43:18','53bffae8-18b0-473d-87e3-0721fee218aa'),(21,11,2,'contact','contact',1,'2022-04-29 18:43:18','2022-04-29 18:43:18','d4591692-6db3-46c5-b719-f9c56d94d048'),(22,12,1,'contact','contact',1,'2022-04-29 18:43:18','2022-04-29 18:43:18','216c3b29-0e7f-452e-809a-0d259dad0a22'),(23,12,2,'contact','contact',1,'2022-04-29 18:43:18','2022-04-29 18:43:18','de287103-4e7e-464c-9c32-e0265832882a'),(24,13,1,'contact','contact',1,'2022-04-29 18:43:19','2022-04-29 18:43:19','f13876c9-ee6a-4b01-a295-1876d3de703d'),(25,13,2,'contact','contact',1,'2022-04-29 18:43:19','2022-04-29 18:43:19','eaecf070-5982-42de-8c43-ea9dde2cca4f'),(26,14,1,'contact','contact',1,'2022-04-29 18:47:37','2022-04-29 18:47:37','12024d2f-7ada-4124-bfb0-251796fba551'),(27,14,2,'contact','contact',1,'2022-04-29 18:47:37','2022-04-29 18:47:37','6b74d61e-7add-4ba7-8470-a4b34bd5817f'),(28,15,1,'blog','blog',1,'2022-04-29 20:00:58','2022-05-12 17:54:52','5898fc0a-a32e-4081-b3af-a42b9724f7cf'),(29,15,2,'blog','blog',1,'2022-04-29 20:00:58','2022-05-12 17:40:55','5cac833b-3608-4b83-a3bc-391d135c7d31'),(36,19,1,'contact','contact',1,'2022-05-12 17:36:09','2022-05-12 17:36:09','54139ae5-15d3-4780-a850-eb2da80407c7'),(37,19,2,'contact','contact',1,'2022-05-12 17:36:09','2022-05-12 17:36:09','f8eecd9b-b5d2-40e6-bbac-4704572c9759'),(38,20,1,'contact','contact',1,'2022-05-12 17:36:10','2022-05-12 17:36:10','2c8b5131-6699-48c7-bae3-a2410ab99e8c'),(39,20,2,'contact','contact',1,'2022-05-12 17:36:10','2022-05-12 17:36:10','232cc97a-2f1b-4f9b-91d8-c43b721ac1f4'),(54,28,1,'blog-overview','blog-overview',1,'2022-05-12 17:45:04','2022-05-12 17:45:04','20314f4e-78d2-4424-bcc0-188c5b876369'),(55,28,2,'blog','blog',1,'2022-05-12 17:45:05','2022-05-12 17:45:05','4fd0572d-425c-49f2-8a57-fffc1ea03c1a'),(56,29,1,'blog-overview','blog-overview',1,'2022-05-12 17:45:05','2022-05-12 17:45:05','2d0e6fbd-5c69-41bc-b4cc-3014f3e89061'),(57,29,2,'blog','blog',1,'2022-05-12 17:45:05','2022-05-12 17:45:05','3c64fa77-2a5f-4679-885c-e1c65bc0d273'),(58,30,1,'blog-overview','blog-overview',1,'2022-05-12 17:45:34','2022-05-12 17:45:34','03fdffb4-930a-4fd0-bf3b-e2bd5dda4ced'),(59,30,2,'blog','blog',1,'2022-05-12 17:45:35','2022-05-12 17:45:35','167b7477-775f-40dc-95f7-d2cbd3cee684'),(60,31,1,'blog-overview','blog-overview',1,'2022-05-12 17:45:35','2022-05-12 17:45:35','9c40f269-5143-4105-bdc4-16d8225d9aa7'),(61,31,2,'blog','blog',1,'2022-05-12 17:45:35','2022-05-12 17:45:35','f316fe18-af94-4853-ac9d-1db006a86183'),(62,32,2,'test','blog/test',1,'2022-05-12 17:45:48','2022-05-12 18:01:22','f8db7236-da40-4567-8b39-dd4d1d5b4fc7'),(63,32,1,'test','blog/test',1,'2022-05-12 17:45:48','2022-05-22 13:13:55','072966d2-1c6e-4f14-a8d3-d34efcc2ff20'),(64,33,2,'test','test',1,'2022-05-12 17:45:57','2022-05-12 17:45:57','88bce4c3-5451-4843-8518-707683f9e3eb'),(65,33,1,'test','test',1,'2022-05-12 17:45:58','2022-05-12 17:45:58','8e4e2c76-3d24-478d-a869-d0de94209a6a'),(68,35,1,'blog','blog',1,'2022-05-12 17:54:52','2022-05-12 17:54:52','cd371551-e741-4148-bb1e-69116ab00eed'),(69,35,2,'blog','blog',1,'2022-05-12 17:54:52','2022-05-12 17:54:52','4c9e1563-b8fe-44a8-9c6d-3509b6230140'),(70,36,1,'blog','blog',1,'2022-05-12 17:57:29','2022-05-12 17:57:29','b725d473-52a3-4358-a16e-0fb9887e1bd2'),(71,36,2,'blog','blog',1,'2022-05-12 17:57:29','2022-05-12 17:57:29','65a41d09-54e2-48b6-a4b5-b13c80240191'),(72,37,1,'blog','blog',1,'2022-05-12 17:57:30','2022-05-12 17:57:30','5c296a53-9a43-40d6-9f9c-3af0db84c75d'),(73,37,2,'blog','blog',1,'2022-05-12 17:57:30','2022-05-12 17:57:30','433321c5-5c31-4931-9cfc-bb2d79eab703'),(74,38,1,'blog','blog',1,'2022-05-12 17:58:25','2022-05-12 17:58:25','d046e42c-e3de-4693-8222-19d45276fa9e'),(75,38,2,'blog','blog',1,'2022-05-12 17:58:25','2022-05-12 17:58:25','d7a9fab6-002b-4036-a4dd-5b39eb462461'),(76,39,2,'blog','blog',1,'2022-05-12 17:58:31','2022-05-12 17:58:31','18c10fb4-3be7-4ac6-9905-081c998892b3'),(77,39,1,'blog','blog',1,'2022-05-12 17:58:31','2022-05-12 17:58:31','31611f05-912d-4b42-8f9a-6821995cdf8a'),(78,40,1,'contact','contact',1,'2022-05-12 18:14:40','2022-05-12 18:14:40','d0b4a1d9-cdbe-42b5-9357-5155aa2a3860'),(79,40,2,'contact','contact',1,'2022-05-12 18:14:40','2022-05-12 18:14:40','ced41456-bfcd-47d2-84d9-5ce665c78ea0'),(80,41,1,'red',NULL,1,'2022-05-13 17:59:58','2022-05-13 18:00:18','7a7b4869-7b24-4a29-b9be-9e1818e74d32'),(81,41,2,'red',NULL,1,'2022-05-13 17:59:59','2022-05-13 18:00:19','8fb36d58-522b-4ec0-8d04-4da8afcfdbd1'),(82,42,1,'orange',NULL,1,'2022-05-13 18:00:36','2022-05-13 18:00:43','ac9d053e-99c8-4560-b9f8-20fe4ab3cdd3'),(83,42,2,'__temp_rlkbmkkugefzugqmllafeupdhpludhvwzhoz',NULL,1,'2022-05-13 18:00:36','2022-05-13 18:00:36','390e02b2-f33b-4f5f-a139-0c798a658304'),(84,43,1,'green',NULL,1,'2022-05-13 18:00:46','2022-05-13 18:00:56','16336c94-9c63-4a3a-acf0-cede66afe280'),(85,43,2,'__temp_yzfrajbuxtdojikfmbxkalvhmwjbtebvthtc',NULL,1,'2022-05-13 18:00:46','2022-05-13 18:00:46','ff2a8d72-ecce-4df6-884e-9562854b7a71'),(86,44,1,'blue',NULL,1,'2022-05-13 18:00:57','2022-05-13 18:01:08','b3091c7b-362a-4439-acf3-0df535e85525'),(87,44,2,'__temp_nrlpvotkjtsvqbwvxsagzhdgpjdlpshoqnpi',NULL,1,'2022-05-13 18:00:58','2022-05-13 18:00:58','cbed512f-1b66-4a10-8326-3ca36cb060a8'),(88,45,1,'purple',NULL,1,'2022-05-13 18:01:11','2022-05-13 18:01:18','fd2ab766-48cf-4e2b-96f5-55bf2f55e51a'),(89,45,2,'__temp_lwuazyokhtumlqhpcjvpfxiufksemwyjvfyw',NULL,1,'2022-05-13 18:01:11','2022-05-13 18:01:11','e5fdfca9-9d6d-4347-990d-62d10c9044b9'),(90,46,1,'purple',NULL,1,'2022-05-13 18:01:21','2022-05-13 18:01:36','6a87d5a4-7673-4fe0-b8c9-d1506fa60df5'),(91,46,2,'__temp_impxxmmxftbpdgsoqsyqzgfyadwtfnuwzmca',NULL,1,'2022-05-13 18:01:22','2022-05-13 18:01:22','735e1e0a-c168-49d3-b103-bbd3e26f17c3'),(92,47,1,'pink',NULL,1,'2022-05-13 18:01:38','2022-05-13 18:01:46','e21fadfa-bce0-4c6f-b505-b3679ac1b9d4'),(93,47,2,'__temp_dfdmnnbssydvobffmdhyiuxkpgschxdcfjcc',NULL,1,'2022-05-13 18:01:38','2022-05-13 18:01:38','5c463143-f41e-46a6-9031-c1da277bd045'),(94,48,1,'blog','blog',1,'2022-05-13 19:34:13','2022-05-13 19:34:13','1e3191a7-3af5-4f0f-805a-3ec70841ab51'),(95,48,2,'blog','blog',1,'2022-05-13 19:34:13','2022-05-13 19:34:13','503989d0-a9b6-4799-a29a-813faa069b13'),(98,50,1,NULL,NULL,1,'2022-05-16 07:06:16','2022-05-16 07:06:16','b14d8c4a-12ac-4228-ba46-51b3ce21915d'),(99,50,2,NULL,NULL,1,'2022-05-16 07:06:16','2022-05-16 07:06:16','92d7d3c1-51e5-4dc7-8903-583362299aae'),(100,51,1,NULL,NULL,1,'2022-05-16 07:06:40','2022-05-16 07:06:40','42d4bcc1-84bb-40db-be75-28d7174eec27'),(101,51,2,NULL,NULL,1,'2022-05-16 07:06:40','2022-05-16 07:06:40','8c764b75-aafe-4fba-841b-626f8f1f50a8'),(102,52,1,'blog','blog',1,'2022-05-16 07:45:34','2022-05-16 07:45:34','87e8a527-7214-475f-8b00-cf31329e2fdf'),(103,52,2,'blog','blog',1,'2022-05-16 07:45:34','2022-05-16 07:45:34','4a102ef4-0bb6-417d-8583-0aa678a85a8e'),(104,53,1,NULL,NULL,1,'2022-05-16 07:45:34','2022-05-16 07:45:34','fde95a94-6d1b-4ca8-bf68-c5ce846dba23'),(105,53,2,NULL,NULL,1,'2022-05-16 07:45:34','2022-05-16 07:45:34','42723910-c2de-4dd1-85d1-5855ddda2592'),(108,55,1,'test','blog/test',1,'2022-05-22 13:13:57','2022-05-22 13:13:57','fffd3a3e-cec4-4721-a282-68b850c260dd'),(109,55,2,'test','blog/test',1,'2022-05-22 13:13:57','2022-05-22 13:13:57','419c36bc-a3d8-47a2-969a-d03274e838ae'),(110,56,1,'test','blog/test',1,'2022-05-22 13:20:48','2022-05-22 13:20:48','08eb3fbd-a458-4dc3-a90e-6118079cdc08'),(111,56,2,'test','blog/test',1,'2022-05-22 13:20:48','2022-05-22 13:20:48','304d03d9-7ca0-47f4-a38d-5a5e54be7cc8');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_arugptucazxobgablqggikhffwpfkkmumbiv` (`postDate`),
  KEY `idx_pvnidcgfjppmvmdyzhtbizutxzwkvveichfw` (`expiryDate`),
  KEY `idx_rlkjdjyroftosnexemwqnaqosprshpbynmxo` (`authorId`),
  KEY `idx_htuoemdklzofdncdrztefdlmwwnklrhtfnch` (`sectionId`),
  KEY `idx_falomqmqhzmmflhcgwngnjqdbsxajothwggd` (`typeId`),
  KEY `fk_zansyudfrkvavtgaeqyhrjclrkqvbzbulkqv` (`parentId`),
  CONSTRAINT `fk_cfhltignonjohxtxqeovkrowiyzemrxaewxu` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cjxvaxuhjuceblzfhpvgrcalrvpiafiwxbff` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_irlgdontnpxweetqmxdkxvtpmvtzhiqkmeoh` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ppcizesaifdzxlqhuulsiuelghiwlqzqytyh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zansyudfrkvavtgaeqyhrjclrkqvbzbulkqv` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,2,NULL,2,NULL,'2022-02-14 21:25:00',NULL,1,'2022-02-14 21:25:35','2022-02-14 21:25:35'),(3,2,NULL,2,NULL,'2022-02-14 21:25:00',NULL,NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35'),(4,3,NULL,3,NULL,'2022-02-14 21:25:00',NULL,1,'2022-02-14 21:25:35','2022-02-14 21:25:35'),(5,3,NULL,3,NULL,'2022-02-14 21:25:00',NULL,NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35'),(6,4,NULL,4,NULL,'2022-02-14 21:25:00',NULL,NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35'),(7,4,NULL,4,NULL,'2022-02-14 21:25:00',NULL,NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35'),(9,4,NULL,4,NULL,'2022-02-14 21:25:00',NULL,NULL,'2022-04-29 18:41:54','2022-04-29 18:41:54'),(10,4,NULL,4,NULL,'2022-02-14 21:25:00',NULL,NULL,'2022-04-29 18:41:55','2022-04-29 18:41:55'),(11,6,NULL,6,NULL,'2022-04-29 18:43:00',NULL,NULL,'2022-04-29 18:43:18','2022-04-29 18:43:18'),(12,6,NULL,6,NULL,'2022-04-29 18:43:00',NULL,NULL,'2022-04-29 18:43:18','2022-04-29 18:43:18'),(13,6,NULL,6,NULL,'2022-04-29 18:43:00',NULL,NULL,'2022-04-29 18:43:19','2022-04-29 18:43:19'),(14,6,NULL,6,NULL,'2022-04-29 18:43:00',NULL,NULL,'2022-04-29 18:47:37','2022-04-29 18:47:37'),(15,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-04-29 20:00:58','2022-04-29 20:00:58'),(19,6,NULL,6,NULL,'2022-04-29 18:43:00',NULL,NULL,'2022-05-12 17:36:09','2022-05-12 17:36:09'),(20,6,NULL,6,NULL,'2022-04-29 18:43:00',NULL,NULL,'2022-05-12 17:36:10','2022-05-12 17:36:10'),(28,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:45:04','2022-05-12 17:45:04'),(29,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:45:05','2022-05-12 17:45:05'),(30,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:45:34','2022-05-12 17:45:34'),(31,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:45:35','2022-05-12 17:45:35'),(32,7,NULL,7,8,'2022-05-12 17:45:00',NULL,NULL,'2022-05-12 17:45:48','2022-05-12 17:45:57'),(33,7,NULL,7,8,'2022-05-12 17:45:00',NULL,NULL,'2022-05-12 17:45:57','2022-05-12 17:45:57'),(35,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:54:52','2022-05-12 17:54:52'),(36,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:57:29','2022-05-12 17:57:29'),(37,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:57:30','2022-05-12 17:57:30'),(38,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:58:25','2022-05-12 17:58:25'),(39,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-12 17:58:31','2022-05-12 17:58:31'),(40,6,NULL,6,NULL,'2022-04-29 18:43:00',NULL,NULL,'2022-05-12 18:14:40','2022-05-12 18:14:40'),(48,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-13 19:34:13','2022-05-13 19:34:13'),(52,8,NULL,8,NULL,'2022-04-29 20:00:00',NULL,NULL,'2022-05-16 07:45:34','2022-05-16 07:45:34'),(55,7,NULL,7,8,'2022-05-12 17:45:00',NULL,NULL,'2022-05-22 13:13:57','2022-05-22 13:13:57'),(56,7,NULL,7,8,'2022-05-12 17:45:00',NULL,NULL,'2022-05-22 13:20:48','2022-05-22 13:20:48');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `titleFormat` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ufrvbusjzejrxzyrqaljycrxrxvfdubtyofi` (`name`,`sectionId`),
  KEY `idx_vxzrhjnwukgxklxapkcyeztgdknxafkgliaz` (`handle`,`sectionId`),
  KEY `idx_gazkvrusxmqlecabjoaijsieuzegkqflnvji` (`sectionId`),
  KEY `idx_kwyxtnikrehahhpkszkkjncxybhvvfuxdokg` (`fieldLayoutId`),
  KEY `idx_hgygpmjxpsitjudcjtbnxprdedjkqhnhtzgi` (`dateDeleted`),
  CONSTRAINT `fk_xkvhmkwwsazqwdyjthyevoydhojhbjvyqvyb` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zmehlwgztntyqjdubqecuksbbsiwozligdzg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,4,'Blog','blog',1,'site',NULL,NULL,1,'2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:54','796edc01-1b41-4583-b2a9-6de0e3015cd1'),(2,2,5,'Blog Overview','blogOverview',1,'site',NULL,'{section.name|raw}',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:41','60fb56ee-fa6f-443d-8088-873fd62c3706'),(3,3,6,'Contact','contact',1,'site',NULL,'{section.name|raw}',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:47','c5553e55-028a-4698-ab75-22816d070c93'),(4,4,7,'Home','home',1,'site',NULL,'{section.name|raw}',1,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'a57a7266-7418-4d78-af8e-3a3950389f39'),(5,5,8,'Pages','pages',1,'site',NULL,NULL,1,'2022-02-14 21:25:36','2022-02-14 21:25:36',NULL,'4873fd21-756a-4934-ac48-7b6f5d2d0087'),(6,6,9,'Contact','contact',1,'site',NULL,'{section.name|raw}',1,'2022-04-29 18:43:18','2022-04-29 18:47:36',NULL,'a209a002-c58f-4520-b709-cd52a88e9d6b'),(7,7,10,'Default','default',1,'site',NULL,NULL,1,'2022-04-29 19:05:46','2022-04-29 19:05:46',NULL,'f3c09b26-065d-4c42-b4a6-2665764ec9fa'),(8,8,11,'Blog','blog',1,'site',NULL,'{section.name|raw}',1,'2022-04-29 20:00:58','2022-05-12 17:57:30',NULL,'e9963072-edc2-4605-bc24-39a15f9ccc35');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expressforms_forms`
--

DROP TABLE IF EXISTS `expressforms_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expressforms_forms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(100) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `handle` varchar(100) NOT NULL,
  `description` text,
  `color` varchar(20) DEFAULT NULL,
  `submissionTitle` varchar(255) NOT NULL,
  `saveSubmissions` tinyint(1) NOT NULL DEFAULT '1',
  `adminNotification` varchar(255) DEFAULT NULL,
  `adminEmails` text,
  `submitterNotification` varchar(255) DEFAULT NULL,
  `submitterEmailField` varchar(100) DEFAULT NULL,
  `spamCount` int unsigned NOT NULL DEFAULT '0',
  `fields` mediumtext,
  `integrations` mediumtext,
  `sortOrder` int DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `handle` (`handle`),
  UNIQUE KEY `expressforms_forms_handle_unq_idx` (`handle`),
  KEY `expressforms_forms_sortOrder_idx` (`sortOrder`),
  KEY `expressforms_forms_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `expressforms_forms_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expressforms_forms`
--

LOCK TABLES `expressforms_forms` WRITE;
/*!40000 ALTER TABLE `expressforms_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `expressforms_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expressforms_resource_fields`
--

DROP TABLE IF EXISTS `expressforms_resource_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expressforms_resource_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `resourceId` int NOT NULL,
  `handle` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `required` tinyint(1) DEFAULT NULL,
  `settings` text,
  `category` varchar(255) DEFAULT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `expressforms_resource_fields_resourceId_handle_category_unq_idx` (`resourceId`,`handle`,`category`),
  KEY `expressforms_resource_fields_sortOrder_idx` (`sortOrder`),
  CONSTRAINT `expressforms_resource_fields_resourceId_fk` FOREIGN KEY (`resourceId`) REFERENCES `expressforms_resources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expressforms_resource_fields`
--

LOCK TABLES `expressforms_resource_fields` WRITE;
/*!40000 ALTER TABLE `expressforms_resource_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `expressforms_resource_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expressforms_resources`
--

DROP TABLE IF EXISTS `expressforms_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expressforms_resources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `typeClass` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `sortOrder` int NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `expressforms_resources_typeClass_handle_unq_idx` (`typeClass`,`handle`),
  KEY `expressforms_resources_sortOrder_idx` (`sortOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expressforms_resources`
--

LOCK TABLES `expressforms_resources` WRITE;
/*!40000 ALTER TABLE `expressforms_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `expressforms_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expressforms_submissions`
--

DROP TABLE IF EXISTS `expressforms_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expressforms_submissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `formId` int NOT NULL,
  `incrementalId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `expressforms_submissions_incrementalId_unq_idx` (`incrementalId`),
  KEY `expressforms_submissions_formId_fk` (`formId`),
  CONSTRAINT `expressforms_submissions_formId_fk` FOREIGN KEY (`formId`) REFERENCES `expressforms_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `expressforms_submissions_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expressforms_submissions`
--

LOCK TABLES `expressforms_submissions` WRITE;
/*!40000 ALTER TABLE `expressforms_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `expressforms_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xmsyxanfibnrffwnbdktiljqntdljersadvv` (`name`),
  KEY `idx_gtpjlnyghdspxpcpjpddvkycsnuzvkegbwoj` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Global','2022-02-14 21:25:34','2022-02-14 21:25:34',NULL,'6bb82573-3aa5-4763-b4ca-603601dce3d2'),(2,'Common','2022-02-14 21:25:34','2022-02-14 21:25:34',NULL,'6e6e5ab5-ec46-433d-80af-42840709af85'),(3,'Blog','2022-04-29 19:10:13','2022-04-29 19:10:13',NULL,'7e985e9f-e680-483b-8355-eaa0ffe93374');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_irkcryzmlsgsrpzqiqjcznlymnelqzmqgctg` (`layoutId`,`fieldId`),
  KEY `idx_lojoxjludzwfyavusncyudfdoktkahkrgmyg` (`sortOrder`),
  KEY `idx_hqslfdvaaiarkdmcfcdvrybiwoqbcfyiggto` (`tabId`),
  KEY `idx_pafmtgwuubrvyjrnscnxbyfegvcdhigcltlx` (`fieldId`),
  CONSTRAINT `fk_bpebndxtmguremjusgntkehkckqfixsmbwar` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eecxrdmvjaodzqqeisrwgrrqtppxgatfjzho` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tsqhlavfoczsulfrvpivaffkyurfqeppmtdt` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (3,4,6,3,0,0,'2022-02-14 21:25:35','2022-02-14 21:25:35','1194fe01-a7cc-480c-baef-3db7b32a0413'),(4,5,8,3,0,0,'2022-02-14 21:25:35','2022-02-14 21:25:35','1e35f338-865c-4487-b10f-bbe85726928b'),(5,6,10,3,0,0,'2022-02-14 21:25:35','2022-02-14 21:25:35','9ad5c7fe-00e0-4712-8072-4a6ce30ef314'),(14,1,41,4,0,1,'2022-05-13 17:59:45','2022-05-13 17:59:45','0e433749-176b-4bc4-857d-6157da7b976a'),(19,11,44,5,0,1,'2022-05-13 19:34:12','2022-05-13 19:34:12','5525f117-7f58-4e77-96e8-cea799a4045c'),(20,11,45,3,0,0,'2022-05-13 19:34:12','2022-05-13 19:34:12','5ac7ef38-6f6f-4f7b-b9bc-a31dddd47259'),(34,12,53,7,0,0,'2022-05-16 07:46:08','2022-05-16 07:46:08','10733885-6d14-4860-b024-f509cba3e8e7'),(35,12,53,6,0,1,'2022-05-16 07:46:08','2022-05-16 07:46:08','e168b1f5-0bd3-4e45-954e-e8c39a1d0221'),(36,10,54,9,0,1,'2022-05-22 13:02:11','2022-05-22 13:02:11','666047f1-444f-46cb-bbc6-47b9511d6b61'),(37,10,55,3,0,0,'2022-05-22 13:02:11','2022-05-22 13:02:11','c8df0d6b-3528-47f5-a5d1-2383fe80af15');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_msotqxgmddjsaonvjxflwgshwijmjcxvzuno` (`dateDeleted`),
  KEY `idx_omsngzjwvixrqpksoaxueshujsnzoxsjldyc` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Category','2022-02-14 21:25:34','2022-02-14 21:25:34',NULL,'f4c858c9-307a-4cff-9f34-412de984cc39'),(2,'craft\\elements\\GlobalSet','2022-02-14 21:25:34','2022-02-14 21:25:34',NULL,'7c007c3a-2be6-49f4-b030-95c50b49314a'),(3,'craft\\elements\\Asset','2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'ed0618ae-16b1-40e7-b501-f1c7feb9e0a4'),(4,'craft\\elements\\Entry','2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:54','ea9adbc1-ff18-4c5f-a706-8f57981df4f3'),(5,'craft\\elements\\Entry','2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:41','541134c4-68e5-4154-923a-9348390152ba'),(6,'craft\\elements\\Entry','2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:47','0baf945c-3698-4b74-9c0d-4c9ef739a6ec'),(7,'craft\\elements\\Entry','2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'d4a70594-89a4-4579-9d07-2e6aa3695778'),(8,'craft\\elements\\Entry','2022-02-14 21:25:36','2022-02-14 21:25:36',NULL,'1a58eba3-7362-47c6-891d-4b0129387ba9'),(9,'craft\\elements\\Entry','2022-04-29 18:43:18','2022-04-29 18:43:18',NULL,'c362e989-1d89-4904-b246-aa142e0d248c'),(10,'craft\\elements\\Entry','2022-04-29 19:05:46','2022-04-29 19:05:46',NULL,'4c158bd5-b386-4482-b8c7-d6a51c6d64fb'),(11,'craft\\elements\\Entry','2022-04-29 20:00:58','2022-04-29 20:00:58',NULL,'083ce270-97f8-4d12-910d-8beeb83aa17e'),(12,'craft\\elements\\MatrixBlock','2022-05-13 19:32:55','2022-05-13 19:32:55',NULL,'c9465fac-b4f2-410d-9cd3-c60cffd825a3'),(13,'craft\\elements\\MatrixBlock','2022-05-16 07:45:23','2022-05-16 07:45:23','2022-05-16 07:46:06','d34c4dc9-2762-4633-a117-d009c0a93175');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `settings` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `elements` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vofpwlhveppcnjtryjfluqvszzykvozuoyin` (`sortOrder`),
  KEY `idx_qpolhlavwsdsgbxaylojlpfcvvmgebockwrx` (`layoutId`),
  CONSTRAINT `fk_uexegxnehsmlylhddcxfwdaztdlwiffdzeaa` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (5,4,'Content',NULL,'[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"width\":100,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"uid\":\"e43da2b3-75dc-4178-ae7e-f97ee8140630\"}]',1,'2022-02-14 21:25:35','2022-05-11 16:37:56','57c5b2c1-f252-491f-af60-68b6b56e504f'),(6,4,'SEO',NULL,'[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"width\":100,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\",\"uid\":\"e2a7db31-c761-43b0-9b73-28f855958ae5\"}]',2,'2022-02-14 21:25:35','2022-05-11 16:37:56','39838319-222a-4ca2-8e2e-4204c13ce759'),(7,5,'Content',NULL,'[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"width\":100,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"uid\":\"aa992d23-4d6a-4650-b215-d4742ddc2add\"}]',1,'2022-02-14 21:25:35','2022-05-11 16:37:56','45cc97d8-f3c4-4364-8295-de2457f9ea14'),(8,5,'SEO',NULL,'[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"width\":100,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\",\"uid\":\"b87189cb-cb4c-44f3-a529-7f6e4b6f894f\"}]',2,'2022-02-14 21:25:35','2022-05-11 16:37:56','662e4b9d-71d8-403c-8644-e4b059b13c5e'),(9,6,'Content',NULL,'[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"width\":100,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"uid\":\"647585a5-6168-4776-8938-c53f10ebcaa6\"}]',1,'2022-02-14 21:25:35','2022-05-11 16:37:56','a4e413e0-663b-491f-a3ae-051ec9c296f2'),(10,6,'SEO',NULL,'[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"width\":100,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\",\"uid\":\"3f405008-12e7-436b-8cfa-04b351285294\"}]',2,'2022-02-14 21:25:35','2022-05-11 16:37:56','61a69c24-b1da-42ae-a47a-8deb4e3a7741'),(15,2,'Menu',NULL,'[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"width\":50,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"fieldUid\":\"ec412734-268e-44c6-a6f7-f2e534090a2a\",\"uid\":\"ebe86b5a-7044-46f6-904b-d72820501988\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"width\":50,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"fieldUid\":\"f2e5c428-680b-4d82-810b-a0d5e1ead17f\",\"uid\":\"7e6bcd12-7a5d-413f-b9fe-6ab04a5a20bd\"}]',1,'2022-02-14 21:25:36','2022-05-11 16:37:56','496a78eb-465e-4394-86c7-d186c1c7ba5b'),(28,8,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"autocapitalize\":true,\"autocomplete\":false,\"autocorrect\":true,\"class\":null,\"disabled\":false,\"id\":null,\"instructions\":null,\"label\":null,\"max\":null,\"min\":null,\"name\":null,\"orientation\":null,\"placeholder\":null,\"readonly\":false,\"requirable\":false,\"size\":null,\"step\":null,\"tip\":null,\"title\":null,\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"warning\":null,\"width\":100,\"uid\":\"938c51e4-95a8-4a6b-b456-1a7a89ef0b52\"}]',1,'2022-05-11 16:37:55','2022-05-11 16:37:56','b538b700-81e4-42ac-a565-e45a9d3bf203'),(29,8,'SEO','{\"userCondition\":null,\"elementCondition\":null}','[{\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\",\"instructions\":null,\"label\":null,\"required\":false,\"tip\":null,\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"warning\":null,\"width\":100,\"uid\":\"f5867e3f-564c-40fd-bc54-208093a35c6d\"}]',2,'2022-05-11 16:37:55','2022-05-11 16:37:56','aefe0933-1f7e-4848-a8ee-20c1a264eeae'),(30,7,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"autocapitalize\":true,\"autocomplete\":false,\"autocorrect\":true,\"class\":null,\"disabled\":false,\"id\":null,\"instructions\":null,\"label\":null,\"max\":null,\"min\":null,\"name\":null,\"orientation\":null,\"placeholder\":null,\"readonly\":false,\"requirable\":false,\"size\":null,\"step\":null,\"tip\":null,\"title\":null,\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"warning\":null,\"width\":100,\"uid\":\"011ea606-2c37-4640-a9cd-37c3ca575996\"}]',1,'2022-05-11 16:37:55','2022-05-11 16:37:56','b048d4de-41d9-47ad-9374-760ab9a78651'),(31,7,'SEO','{\"userCondition\":null,\"elementCondition\":null}','[{\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\",\"instructions\":null,\"label\":null,\"required\":false,\"tip\":null,\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"warning\":null,\"width\":100,\"uid\":\"ee5b1470-00e2-4a78-a6fb-5e2908945d57\"}]',2,'2022-05-11 16:37:55','2022-05-11 16:37:56','589a361d-0cd7-4a5a-a44a-af18cfbd72a0'),(32,9,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"autocapitalize\":true,\"autocomplete\":false,\"autocorrect\":true,\"class\":null,\"disabled\":false,\"id\":null,\"instructions\":null,\"label\":null,\"max\":null,\"min\":null,\"name\":null,\"orientation\":null,\"placeholder\":null,\"readonly\":false,\"requirable\":false,\"size\":null,\"step\":null,\"tip\":null,\"title\":null,\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"warning\":null,\"width\":100,\"uid\":\"1242584a-c842-4598-bf15-dfc1f53dec45\"}]',1,'2022-05-11 16:37:55','2022-05-11 16:37:56','62ba83da-334c-46ee-9500-0af8ffed3d4b'),(33,9,'SEO','{\"userCondition\":null,\"elementCondition\":null}','[{\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\",\"instructions\":null,\"label\":null,\"required\":false,\"tip\":null,\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"warning\":null,\"width\":100,\"uid\":\"8946303e-f193-430f-88d1-b57f21f7be5b\"}]',2,'2022-05-11 16:37:55','2022-05-11 16:37:56','e94e1904-d810-4289-b393-f6ba7fc65562'),(38,3,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"ad022d95-31c5-4f14-a660-8167e0ff4755\"}]',1,'2022-05-11 16:49:47','2022-05-11 16:49:47','bc8d02a4-f2b7-4351-bdeb-899a174d267d'),(41,1,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\TitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"820a6a9e-fc03-4e5a-baea-a50970939e2c\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"f2c5067c-76c1-4fee-9b0a-58c8627b97c5\",\"fieldUid\":\"5efbbd6a-2d8b-4ef0-b03a-1bf53718f687\"}]',1,'2022-05-13 17:59:45','2022-05-13 17:59:45','83ca09db-3144-47ae-9db0-c3ed02d08e2a'),(44,11,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"3aae76fb-1dc4-4fd1-bff1-5a09435c7757\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"deadc17f-1180-4962-bcd7-a3b673a5ec5c\",\"fieldUid\":\"51c27d0d-e6ac-45ab-92e4-4e2eb69766ff\"}]',1,'2022-05-13 19:34:12','2022-05-13 19:34:12','c37427ee-2bb9-426b-977f-cfbb91ff525e'),(45,11,'SEO','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"c6e33ff7-fa24-4b4d-8093-ad209f66b043\",\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\"}]',2,'2022-05-13 19:34:12','2022-05-13 19:34:12','3403ffe2-6deb-4d35-8277-86fa3238c4d0'),(52,13,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"6b41794b-e115-4574-bac0-f8d8ab7358ca\",\"fieldUid\":\"9193b8e5-9e85-4ad6-9dfc-17f0a0c77968\"}]',1,'2022-05-16 07:45:23','2022-05-16 07:45:23','a2b9936c-a0cf-4e67-9372-43f55912c9b8'),(53,12,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"771d5abb-beb2-41d2-a150-6e6c9460a928\",\"fieldUid\":\"e3e8dd6d-7223-4e6c-b085-4d618b2671b0\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"7542e498-f8ca-4a62-a427-8e7f122f8618\",\"fieldUid\":\"9a81afee-7773-471a-8523-952141569d38\"}]',1,'2022-05-16 07:46:08','2022-05-16 07:46:08','4515fdce-f496-4d1c-af29-2b2ea6de5f11'),(54,10,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"c1807e1b-ca51-46b8-a1bd-df70a2557eea\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"c2ee051a-7c82-44b3-a125-9bfc9b78feb7\",\"fieldUid\":\"2b5c3999-f111-4535-8ecd-a81e95483d94\"}]',1,'2022-05-22 13:02:11','2022-05-22 13:02:11','d0e34251-965c-4e68-adb6-6e3821aee376'),(55,10,'SEO','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"3b835e2e-d029-4932-b2e3-547bd4712d92\",\"fieldUid\":\"db74e3e8-29b2-475d-bbae-ff18672720f1\"}]',2,'2022-05-22 13:02:11','2022-05-22 13:02:11','d9d938d9-f19a-400b-ad0f-79ef99f17837');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `instructions` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `translationKeyFormat` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `settings` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gjxzwcpkhvgnbvxdwebtvlixzlacierkjpcg` (`handle`,`context`),
  KEY `idx_loqdfugmxmwgcobqgsyovhazlfxbsiwtdajz` (`groupId`),
  KEY `idx_kdizbyogobephzabntlkwjtdaeljcvetmvtd` (`context`),
  CONSTRAINT `fk_nfkfroownqhgnypfomixwcsmcjyekyvtsmom` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (3,2,'SEO','seo','global','xicqkdxc','',0,'site',NULL,'ether\\seo\\fields\\SeoField','{\"description\":\"\",\"hideSocial\":\"\",\"robots\":[\"\",\"\",\"\",\"\",\"\",\"\"],\"socialImage\":\"\",\"suffixAsPrefix\":null,\"title\":[{\"key\":\"1\",\"locked\":\"0\",\"template\":\"{title}\"},{\"key\":\"2\",\"locked\":\"1\",\"template\":\" - {{ currentSite.group.name }}\"}],\"titleSuffix\":null}','2022-02-14 21:25:34','2022-02-14 21:25:34','db74e3e8-29b2-475d-bbae-ff18672720f1'),(4,3,'Blog Category Color','blogCategoryColor','global','ayvjetxk','',0,'none',NULL,'craft\\fields\\Dropdown','{\"optgroups\":true,\"options\":[{\"label\":\"Red\",\"value\":\"red\",\"default\":\"\"},{\"label\":\"Orange\",\"value\":\"orange\",\"default\":\"\"},{\"label\":\"Green\",\"value\":\"green\",\"default\":\"\"},{\"label\":\"Blue\",\"value\":\"blue\",\"default\":\"\"},{\"label\":\"Purple\",\"value\":\"purple\",\"default\":\"\"},{\"label\":\"Pink\",\"value\":\"pink\",\"default\":\"\"}]}','2022-04-29 19:45:07','2022-04-29 19:45:07','5efbbd6a-2d8b-4ef0-b03a-1bf53718f687'),(5,2,'Banner','banner','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":1,\"maxBlocks\":1,\"contentTable\":\"{{%matrixcontent_banner}}\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null}','2022-05-13 19:32:48','2022-05-16 07:46:03','51c27d0d-e6ac-45ab-92e4-4e2eb69766ff'),(6,NULL,'Body','body','matrixBlockType:2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8','nfdgofga',NULL,0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":\"Simple.json\",\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2022-05-13 19:32:54','2022-05-13 19:33:50','9a81afee-7773-471a-8523-952141569d38'),(7,NULL,'Titel','titel','matrixBlockType:2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8','hauxjttk',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-05-13 19:32:55','2022-05-13 19:32:55','e3e8dd6d-7223-4e6c-b085-4d618b2671b0'),(9,3,'Blog Category','blogCategory','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Categories','{\"allowLimit\":false,\"allowMultipleSources\":false,\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showSiteMenu\":false,\"source\":\"group:541a135e-c132-4a7f-b2ef-9869b60caba3\",\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2022-05-22 13:01:25','2022-05-22 13:01:25','2b5c3999-f111-4535-8ecd-a81e95483d94');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xdqxmiyrdjokemzozvljluvxralshfyiyzkn` (`name`),
  KEY `idx_diifosfdrvrbnyhddsbvfuniuhbleheovidw` (`handle`),
  KEY `idx_sxexyspjsbvcalmbawfrjnijyhmkplzmmkzu` (`fieldLayoutId`),
  KEY `idx_aryjavmnlvhzrtizfgrdysagvhhkffbwexuv` (`sortOrder`),
  CONSTRAINT `fk_ictkbyjqphhhfbvbjmhlsdothondwnfajutc` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ixwwockdvraozadpoymudwsdfaweadppveku` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
INSERT INTO `globalsets` VALUES (1,'Navigation','navigation',2,1,'2022-02-14 21:25:35','2022-02-14 21:25:35','2d0fb778-2d78-49c0-b94d-740200560f8f');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `scope` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','5a91ab6b-5698-4382-8d79-9b7c950b67f4');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `accessToken` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xxicduskiiorlstjvujooandinzbfrxdxfnl` (`accessToken`),
  UNIQUE KEY `idx_mkpwuthzlqgbhhdouoitjrnrahnldxbuntbh` (`name`),
  KEY `fk_ssugjlhavnkqdvbppzmogugyxqbhahonepwk` (`schemaId`),
  CONSTRAINT `fk_ssugjlhavnkqdvbppzmogugyxqbhahonepwk` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
INSERT INTO `gqltokens` VALUES (1,'Public Token','__PUBLIC__',1,NULL,NULL,1,'2022-02-14 21:25:36','2022-02-14 21:25:36','f7fe13a3-bad0-425d-8b9c-2c1da21e01bd');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `transformString` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ukzonkbovqfjyfcqdwrtxxnryyadzppewsoy` (`assetId`,`format`,`transformString`),
  KEY `idx_jevyshhvcysnelwfsoomqptobksnstnjahea` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fhzcentfhgcrowmejbjhilzbfywkowioqzjd` (`name`),
  KEY `idx_ykiycbcxqaggwpckatpsnkufrvqpthnyuwii` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.0.2','4.0.0.9',0,'aqzfxfrrvyzn','3@vhbnfguhlx','2022-02-14 21:25:33','2022-05-22 13:13:52','124a5a7e-4a1d-445c-ab1b-ae3a8a956202');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fhojfcvmnondmstohhhrzssurxyelrgkecmp` (`primaryOwnerId`),
  KEY `idx_kpydmxcgcskksoyrerremivjhbfmbaxfcywh` (`fieldId`),
  KEY `idx_coabgcoyohdwtozznwpsfitnhsuyxpgzlskn` (`typeId`),
  CONSTRAINT `fk_afyloqiszpkyoyzkawkrjisbesnadquvcvjb` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dnhelinaunkgidhsqnyvhyvsvimwvlzysrsu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mbkfjuhpcpmutmtzitheknckkmhzwkcfzexp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oeavzyjfuttesmrsxhlpnpyqtferfrskwbkl` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_wxdlaqiljhqjpwfjdtoolgwtihusmlisoxqi` (`ownerId`),
  CONSTRAINT `fk_wxdlaqiljhqjpwfjdtoolgwtihusmlisoxqi` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xcteqgtlpmuvlipeoqjpwqndixxtxabmaquw` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ijltjihxguhjhncrvwfanwwyeyqqsxvthvct` (`name`,`fieldId`),
  KEY `idx_uvffbqlpqundwwsxfnezolmbfwtvmdvbgdol` (`handle`,`fieldId`),
  KEY `idx_xixaehpiywefqxcicpotfjvylsieqympuzul` (`fieldId`),
  KEY `idx_gieiopuzlybalsmwesmjtkkwklcrgfjvhvhc` (`fieldLayoutId`),
  CONSTRAINT `fk_cwpplghkqgjiybhvlzjxeyvwozsvtznrqaau` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xudjqbwzawdxvwsarwsdkeahbtgobyxphqfd` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
INSERT INTO `matrixblocktypes` VALUES (1,5,12,'Banner','banner',1,'2022-05-13 19:32:56','2022-05-13 19:32:56','2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixcontent_banner`
--

DROP TABLE IF EXISTS `matrixcontent_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixcontent_banner` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_banner_body_nfdgofga` text,
  `field_banner_titel_hauxjttk` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kfirusibeflobktuoudpwihdjuznfvakarbw` (`elementId`,`siteId`),
  KEY `fk_oaxrrwwygsxzfcwbmfjkekvavapzffsngtoh` (`siteId`),
  CONSTRAINT `fk_exfxygmbeokqlajpvtpadeuchzaavajdsrcf` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oaxrrwwygsxzfcwbmfjkekvavapzffsngtoh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixcontent_banner`
--

LOCK TABLES `matrixcontent_banner` WRITE;
/*!40000 ALTER TABLE `matrixcontent_banner` DISABLE KEYS */;
INSERT INTO `matrixcontent_banner` VALUES (1,50,1,'2022-05-16 07:06:16','2022-05-16 07:06:16','b3f1cae3-7311-4407-b6c4-08fe7aedca2f',NULL,NULL),(2,50,2,'2022-05-16 07:06:16','2022-05-16 07:06:16','42630f31-7731-49ce-8323-55478632e5ef',NULL,NULL),(3,51,1,'2022-05-16 07:06:40','2022-05-16 07:06:40','2179640e-c410-4247-9a94-f86e3226cf02',NULL,NULL),(4,51,2,'2022-05-16 07:06:40','2022-05-16 07:06:40','b7a9d478-0163-43e1-b738-51a014d123d1',NULL,NULL),(5,53,1,'2022-05-16 07:45:34','2022-05-16 07:45:34','b91034f2-8826-4c8a-8f08-5468e1751471',NULL,NULL),(6,53,2,'2022-05-16 07:45:34','2022-05-16 07:45:34','e1d6c977-3783-47d0-82e7-910e02de0760',NULL,NULL);
/*!40000 ALTER TABLE `matrixcontent_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ntltcsawpxeijzxaheeoyskpiyvlfnrqwboq` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (3,'plugin:seo','Install','2022-02-14 21:25:34','2022-02-14 21:25:34','2022-02-14 21:25:34','9dde5bb7-8677-4cf8-9771-7fe623fc1786'),(4,'plugin:seo','m180906_152947_add_site_id_to_redirects','2022-02-14 21:25:34','2022-02-14 21:25:34','2022-02-14 21:25:34','72e90308-429c-49e6-9c1c-6da3ed9c78ce'),(5,'plugin:seo','m190114_152300_upgrade_to_new_data_format','2022-02-14 21:25:34','2022-02-14 21:25:34','2022-02-14 21:25:34','44720d62-5aff-497d-b609-3d1fe7244a3f'),(6,'plugin:seo','m200518_110721_add_order_to_redirects','2022-02-14 21:25:34','2022-02-14 21:25:34','2022-02-14 21:25:34','256a2016-7498-49b4-ac13-8835afe9e0f4'),(7,'plugin:seo','m201207_124200_add_product_types_to_sitemap','2022-02-14 21:25:34','2022-02-14 21:25:34','2022-02-14 21:25:34','ded57f54-ec97-4e55-ab98-169a6610a577'),(22,'craft','Install','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','89351adf-042c-40b9-8619-86e4fb71883e'),(23,'craft','m150403_183908_migrations_table_changes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','af18098e-f577-4258-b935-aaf1a2b01a5d'),(24,'craft','m150403_184247_plugins_table_changes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','cc095562-e1b4-417f-b440-aa99158f9076'),(25,'craft','m150403_184533_field_version','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9876664d-d57c-430f-8afa-4fa672197993'),(26,'craft','m150403_184729_type_columns','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9714a5b4-0984-4720-af02-656bea3acd41'),(27,'craft','m150403_185142_volumes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','c7bee83c-68d6-412b-82e4-97e5f84ddad5'),(28,'craft','m150428_231346_userpreferences','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','de12a158-7643-4d5c-9ca4-20cdd87a3d22'),(29,'craft','m150519_150900_fieldversion_conversion','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','1a4a1455-af19-475b-9fef-c9c0ef40f444'),(30,'craft','m150617_213829_update_email_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','91721adc-4921-4e94-9991-a5e58a50f591'),(31,'craft','m150721_124739_templatecachequeries','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','e352dd86-b554-4f6f-b5ba-2a4626276688'),(32,'craft','m150724_140822_adjust_quality_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','0df8454f-23d3-4ff8-9648-c2a5b56129f9'),(33,'craft','m150815_133521_last_login_attempt_ip','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','887a87d6-e68b-483e-b019-87e574cff5f4'),(34,'craft','m151002_095935_volume_cache_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2b7328b7-df87-4014-a1a1-f328e8cc2fb1'),(35,'craft','m151005_142750_volume_s3_storage_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','17db8b14-8825-4b65-859f-dcaf1be85f32'),(36,'craft','m151016_133600_delete_asset_thumbnails','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','40658206-11ca-4054-a29a-fcf64b879059'),(37,'craft','m151209_000000_move_logo','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','190fdcdf-391f-45e5-b715-5361046f7df0'),(38,'craft','m151211_000000_rename_fileId_to_assetId','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','1963bc15-74f1-4ba2-97a9-ed637471f1ee'),(39,'craft','m151215_000000_rename_asset_permissions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','0b47e620-69a6-4401-bfa4-b08d8a87f4dc'),(40,'craft','m160707_000001_rename_richtext_assetsource_setting','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','59bfb11a-356e-4c49-91a7-a431197a3b23'),(41,'craft','m160708_185142_volume_hasUrls_setting','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','b17e3ecf-4d1a-425f-add3-9e2ba0703250'),(42,'craft','m160714_000000_increase_max_asset_filesize','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','ed67de6e-cb8e-4591-bec7-7b5c62c24738'),(43,'craft','m160727_194637_column_cleanup','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','bea3af45-7499-40d8-82b7-f922d9d93f98'),(44,'craft','m160804_110002_userphotos_to_assets','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','acc86efa-4d0d-4a3d-a1b1-4e562d3a2e5b'),(45,'craft','m160807_144858_sites','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','93ac68fa-45dc-48eb-83f4-306f5d1755fb'),(46,'craft','m160829_000000_pending_user_content_cleanup','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','8bc17c9b-3699-4833-a25d-858b181d6317'),(47,'craft','m160830_000000_asset_index_uri_increase','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','38978bd8-f8a6-4f5f-a2be-be297e9675b2'),(48,'craft','m160912_230520_require_entry_type_id','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','378ec7ba-7bd5-413c-a870-f49605a3a10f'),(49,'craft','m160913_134730_require_matrix_block_type_id','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4599907a-9746-4632-8bf1-3e2593e1b7d4'),(50,'craft','m160920_174553_matrixblocks_owner_site_id_nullable','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9ef73c87-0f10-465b-aac3-e2a608081a96'),(51,'craft','m160920_231045_usergroup_handle_title_unique','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','7f725039-93b8-413c-8cf7-79fd4f14b927'),(52,'craft','m160925_113941_route_uri_parts','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','3a7c1b5d-9990-44be-8b29-95ab769e417f'),(53,'craft','m161006_205918_schemaVersion_not_null','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','08e95494-29ad-4555-958c-d97585a84c64'),(54,'craft','m161007_130653_update_email_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','8763c8c0-e11a-4eec-9e38-1295b90dd9a0'),(55,'craft','m161013_175052_newParentId','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','7b986754-da36-4ee2-9bd5-b947f67a259d'),(56,'craft','m161021_102916_fix_recent_entries_widgets','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','690115e1-49b6-4ebb-b581-aacfcb07459c'),(57,'craft','m161021_182140_rename_get_help_widget','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','c9c93b13-9481-468e-a080-6bd3a25a41c5'),(58,'craft','m161025_000000_fix_char_columns','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','d7e9093b-1902-4ea2-a8a6-4cdd5ddb2c4e'),(59,'craft','m161029_124145_email_message_languages','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9516dff7-a04c-4a1a-9e41-ab3c80138681'),(60,'craft','m161108_000000_new_version_format','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','b76266f7-e6d4-4878-b4f7-42a2e44d9cca'),(61,'craft','m161109_000000_index_shuffle','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','76955c80-4ebc-46df-ac37-42aa71d78254'),(62,'craft','m161122_185500_no_craft_app','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4e70cb18-7e9a-48b9-ab19-40fa3916a5e9'),(63,'craft','m161125_150752_clear_urlmanager_cache','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','e7ef7b14-3c17-4da5-82c9-4542552e51fd'),(64,'craft','m161220_000000_volumes_hasurl_notnull','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','cef1a759-96e7-401a-a13e-0bcc6e1233c5'),(65,'craft','m170114_161144_udates_permission','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4e45fe85-c570-4968-af9c-6ff7e5ec291b'),(66,'craft','m170120_000000_schema_cleanup','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','0bb1e20c-dbe7-4482-9006-8b524b856271'),(67,'craft','m170126_000000_assets_focal_point','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','3509e8d9-ee27-44a8-8ad3-037a61e6b1ff'),(68,'craft','m170206_142126_system_name','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','077ee8b0-7431-479d-a6a4-c673719f88a3'),(69,'craft','m170217_044740_category_branch_limits','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','904b88f5-1d28-4230-adef-beb5e15b9053'),(70,'craft','m170217_120224_asset_indexing_columns','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9806906e-3235-422e-a6ad-76e398f29d54'),(71,'craft','m170223_224012_plain_text_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','a8aebe2c-6b02-4f2e-96ba-54b33c89df2a'),(72,'craft','m170227_120814_focal_point_percentage','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','6d831bf3-3c81-46cb-97af-2de3cada954a'),(73,'craft','m170228_171113_system_messages','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','49a03fd4-4fa1-4860-ad17-a10417bfa536'),(74,'craft','m170303_140500_asset_field_source_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','f780c35a-eb87-4b4b-aae7-4f6ae8f53a4d'),(75,'craft','m170306_150500_asset_temporary_uploads','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','19fe56ce-7c21-48a7-bd72-3d133f19f38d'),(76,'craft','m170523_190652_element_field_layout_ids','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4572f956-6783-4f80-87d4-eb01be74cf5c'),(77,'craft','m170621_195237_format_plugin_handles','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','8ee6949f-06d3-41c1-924e-e46779c62750'),(78,'craft','m170630_161027_deprecation_line_nullable','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','11931a27-60dc-47f8-92f2-b20ce5eb1e04'),(79,'craft','m170630_161028_deprecation_changes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','1721f981-c96d-4c26-bfef-3725e271fe54'),(80,'craft','m170703_181539_plugins_table_tweaks','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2aeeceee-9867-4db4-8442-ee4929bfffa9'),(81,'craft','m170704_134916_sites_tables','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','02434a80-7092-4f54-b0ff-1e49daf6ec38'),(82,'craft','m170706_183216_rename_sequences','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','7cd77048-72a6-4ad5-9321-5246bed0f594'),(83,'craft','m170707_094758_delete_compiled_traits','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','f6a3dabf-04e6-4d25-8f75-c5c5a1d13f01'),(84,'craft','m170731_190138_drop_asset_packagist','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','581f0294-5a0d-41d4-8684-ac7bd7b52899'),(85,'craft','m170810_201318_create_queue_table','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','5e8a046c-bc1a-42e5-8d39-54a047a4716a'),(86,'craft','m170903_192801_longblob_for_queue_jobs','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','7c12b618-5741-45dc-9a51-7ae327058a17'),(87,'craft','m170914_204621_asset_cache_shuffle','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','59cf092e-37e9-4fc8-812d-5c82831c0886'),(88,'craft','m171011_214115_site_groups','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','3d14f85d-bb08-403b-90aa-d1021dd8f5ae'),(89,'craft','m171012_151440_primary_site','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','3de78fdb-399c-4ec6-a6f5-d44cb61c0a99'),(90,'craft','m171013_142500_transform_interlace','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4e1fc13b-2a51-4c9e-b237-81e1b6613d08'),(91,'craft','m171016_092553_drop_position_select','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','38b27e18-99e8-41ef-b1c5-a6de240e7e88'),(92,'craft','m171016_221244_less_strict_translation_method','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','1f706935-3fac-407c-aab4-bff6bacd36ae'),(93,'craft','m171107_000000_assign_group_permissions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','7dacfdd7-b8e2-4fed-8279-e02253df4d4a'),(94,'craft','m171117_000001_templatecache_index_tune','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','1b9efc4f-13c3-43cf-a8a2-5ec286d6926a'),(95,'craft','m171126_105927_disabled_plugins','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','ea3942dd-3507-4487-8c96-79b205ad04f2'),(96,'craft','m171130_214407_craftidtokens_table','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','db197434-3dc5-4fa5-9eb9-dea9ba80f2e6'),(97,'craft','m171202_004225_update_email_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','8630525d-da77-4c62-b2be-435db11375bf'),(98,'craft','m171204_000001_templatecache_index_tune_deux','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','58eef6c5-7d5f-4790-a868-0d8a5f6440d5'),(99,'craft','m171205_130908_remove_craftidtokens_refreshtoken_column','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','a8ccafdf-1677-4de2-a774-581ac6afe6f9'),(100,'craft','m171218_143135_longtext_query_column','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2e1df5da-2c9d-40f7-9043-1b01e043562f'),(101,'craft','m171231_055546_environment_variables_to_aliases','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','ef123873-2b3a-4cf6-8a2a-cc5942fe628b'),(102,'craft','m180113_153740_drop_users_archived_column','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4f52174d-dae5-40de-9c69-0cae31f7af17'),(103,'craft','m180122_213433_propagate_entries_setting','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','c845b7ef-0f4e-497c-b242-dfd660ca54b6'),(104,'craft','m180124_230459_fix_propagate_entries_values','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','73194e15-7132-4dcc-a2f3-6d968592a623'),(105,'craft','m180128_235202_set_tag_slugs','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','5eff0def-0362-4954-8df2-c215fbc27fc4'),(106,'craft','m180202_185551_fix_focal_points','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','e03d702c-52f8-47ea-b247-5d37b5cfb627'),(107,'craft','m180217_172123_tiny_ints','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','da783c0a-28e8-4660-90ff-1ae7ebf72130'),(108,'craft','m180321_233505_small_ints','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','6bacf051-5b7c-4f8a-bfa3-7867ccf02a7a'),(109,'craft','m180404_182320_edition_changes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','b81cf025-10da-4dd9-b691-9cf06cc5bea8'),(110,'craft','m180411_102218_fix_db_routes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4ca0dc56-f882-4173-9ad4-f9ce00f75519'),(111,'craft','m180416_205628_resourcepaths_table','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','bab67677-ece1-4e6b-951b-657949a42f9d'),(112,'craft','m180418_205713_widget_cleanup','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','024d4e5b-12a8-4d07-8790-6aa5123fbcb8'),(113,'craft','m180425_203349_searchable_fields','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','90b8636e-e260-482a-a207-b47c09ed775d'),(114,'craft','m180516_153000_uids_in_field_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','17c49992-46fe-4bb7-93ac-a0e41566b93c'),(115,'craft','m180517_173000_user_photo_volume_to_uid','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','b4414871-7b4e-49d3-99ed-1553cc7200cd'),(116,'craft','m180518_173000_permissions_to_uid','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','10ca5001-07a7-4dba-8466-2947b962c508'),(117,'craft','m180520_173000_matrix_context_to_uids','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','394cfa13-0482-44f5-9f79-854b00a646c1'),(118,'craft','m180521_172900_project_config_table','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','a53b9484-274f-45cd-829c-2f633473b6a5'),(119,'craft','m180521_173000_initial_yml_and_snapshot','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','f1f7638b-7559-4535-a295-955119486c18'),(120,'craft','m180731_162030_soft_delete_sites','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','76221e03-deca-4774-a63d-b0b7b34004b7'),(121,'craft','m180810_214427_soft_delete_field_layouts','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','f60f8c31-61c1-4e12-a53f-3d5529076eb3'),(122,'craft','m180810_214439_soft_delete_elements','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','470d53da-5e4e-4b4f-a212-f5908bccaef5'),(123,'craft','m180824_193422_case_sensitivity_fixes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','6c487083-d5b3-4a50-8e13-6ac1fcdd8b42'),(124,'craft','m180901_151639_fix_matrixcontent_tables','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','6ed391ea-6b79-4fb2-8710-7e171428157d'),(125,'craft','m180904_112109_permission_changes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','c931a66d-1fbc-425c-8fee-eda1958c487f'),(126,'craft','m180910_142030_soft_delete_sitegroups','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','a5c17025-db4d-408b-a185-c59fa46a71f3'),(127,'craft','m181011_160000_soft_delete_asset_support','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','1af3a9be-b4b8-487b-83eb-c1dd27319767'),(128,'craft','m181016_183648_set_default_user_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2bfdeb13-0e2d-48fe-bd51-dd89c68a2bbc'),(129,'craft','m181017_225222_system_config_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','da3ab188-2510-415f-b455-21ce11439c68'),(130,'craft','m181018_222343_drop_userpermissions_from_config','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','112b0d96-e529-4d93-8574-db61d1cec65c'),(131,'craft','m181029_130000_add_transforms_routes_to_config','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','3c7c20ab-e94c-42ad-b069-b418df96b428'),(132,'craft','m181112_203955_sequences_table','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','a6ad0c2f-9010-47fd-85b7-57671f38a1d7'),(133,'craft','m181121_001712_cleanup_field_configs','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','50c40a79-6dea-44ee-919e-16b8f442598f'),(134,'craft','m181128_193942_fix_project_config','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','357a9787-c098-4c89-ac4a-051cba5cfc00'),(135,'craft','m181130_143040_fix_schema_version','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','af32546c-8c8a-423a-8595-e3f93ce65d83'),(136,'craft','m181211_143040_fix_entry_type_uids','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','e4d0e81b-a2b3-475b-8a47-350f507a8246'),(137,'craft','m181217_153000_fix_structure_uids','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9908d389-4f3e-45d1-b4f3-dd336a949679'),(138,'craft','m190104_152725_store_licensed_plugin_editions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','20044400-e378-4eda-9462-1f8d8537e3ac'),(139,'craft','m190108_110000_cleanup_project_config','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','6c6e27fc-8017-4f96-9240-5000d5c750b9'),(140,'craft','m190108_113000_asset_field_setting_change','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','8804840b-9baf-4748-9888-6c9895eeb9cc'),(141,'craft','m190109_172845_fix_colspan','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','1c852a72-ecc9-4c72-92f8-ec2cd1ac5927'),(142,'craft','m190110_150000_prune_nonexisting_sites','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','89e82a7a-b9d4-4a29-9ff6-aa71c17ce814'),(143,'craft','m190110_214819_soft_delete_volumes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9aa40c6b-bf46-4b88-a950-a155fa969b77'),(144,'craft','m190112_124737_fix_user_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','035c326a-da29-40bc-8b2d-a9b448428483'),(145,'craft','m190112_131225_fix_field_layouts','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','f2bab9c6-27ac-4a76-b0a4-8deef1f74d24'),(146,'craft','m190112_201010_more_soft_deletes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2a91eab0-cd6c-4387-bc97-a6a5abb8ae21'),(147,'craft','m190114_143000_more_asset_field_setting_changes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','ad9c4200-aac8-42c9-8cfd-9da570d0208e'),(148,'craft','m190121_120000_rich_text_config_setting','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','d4826601-365d-4413-8b05-17a38b620647'),(149,'craft','m190125_191628_fix_email_transport_password','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','cb0423da-96a3-4cdc-ac9f-93e8eb04913a'),(150,'craft','m190128_181422_cleanup_volume_folders','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','d3fa3ff5-f4c6-4cf7-a6cc-34918e53a6cf'),(151,'craft','m190205_140000_fix_asset_soft_delete_index','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','0ef962a2-c330-433d-afc5-697cf77b964b'),(152,'craft','m190218_143000_element_index_settings_uid','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9630b0a8-569d-4bbb-8f66-1d624b456ea8'),(153,'craft','m190312_152740_element_revisions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','e16fc2be-eb4c-4f56-b46a-4a5340cea1ba'),(154,'craft','m190327_235137_propagation_method','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','367c610d-f9b4-499b-9d91-11ec3e668ea2'),(155,'craft','m190401_223843_drop_old_indexes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','652806f8-cc2c-4cef-ba90-3b80a5d0c1e6'),(156,'craft','m190416_014525_drop_unique_global_indexes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','528dbed2-4278-4ede-91e6-2c0d41b1b2f8'),(157,'craft','m190417_085010_add_image_editor_permissions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','55578659-318b-4253-9510-bf2f5843a18e'),(158,'craft','m190502_122019_store_default_user_group_uid','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','ec562542-7548-4e69-96a3-79b435442fa4'),(159,'craft','m190504_150349_preview_targets','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','fb966a3d-c8bd-4c37-a482-c5c85ea865be'),(160,'craft','m190516_184711_job_progress_label','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','545a722d-2cfa-4ee6-be10-ec95f6bbabca'),(161,'craft','m190523_190303_optional_revision_creators','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','76d671b3-6bc5-4f59-9491-48b8b46747a2'),(162,'craft','m190529_204501_fix_duplicate_uids','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','84446feb-d23a-402d-9bd7-9d379e4aa015'),(163,'craft','m190605_223807_unsaved_drafts','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','5fe4ad11-1d9a-4251-baf2-60d3296df64a'),(164,'craft','m190607_230042_entry_revision_error_tables','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','24941618-ff2c-4838-b87c-26ea65b7fb45'),(165,'craft','m190608_033429_drop_elements_uid_idx','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','62da086e-a39d-4251-af74-108eb1ff4946'),(166,'craft','m190617_164400_add_gqlschemas_table','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9cacd973-04f5-488c-be70-5f0f622bb9ff'),(167,'craft','m190624_234204_matrix_propagation_method','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','55cd7c2e-7afa-4c0e-994c-3f2df867d4bc'),(168,'craft','m190711_153020_drop_snapshots','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','5bb1ef93-21a6-4eee-b4ba-72af42ab27af'),(169,'craft','m190712_195914_no_draft_revisions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','71ff0df7-3c5f-42f8-9c40-6022300a7845'),(170,'craft','m190723_140314_fix_preview_targets_column','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','dabb4426-6d97-4afa-ab07-cfad0c0dddd9'),(171,'craft','m190820_003519_flush_compiled_templates','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','91dc984e-95b6-4518-b1bd-a1d9f00f0f76'),(172,'craft','m190823_020339_optional_draft_creators','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','86c26bf6-277d-475b-a495-2b0b5e92a67a'),(173,'craft','m190913_152146_update_preview_targets','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','18b90e1c-fdf6-4730-b865-004053814599'),(174,'craft','m191107_122000_add_gql_project_config_support','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2ce6375b-cb20-4d5f-a626-50c15c067a3b'),(175,'craft','m191204_085100_pack_savable_component_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','57d06ccc-d35e-4054-8681-b67de05dd423'),(176,'craft','m191206_001148_change_tracking','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','427b4f33-6b95-40f9-82d8-2af5dd9c318c'),(177,'craft','m191216_191635_asset_upload_tracking','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','a4314042-d1cf-4921-9d0b-2bcdf17dcdfa'),(178,'craft','m191222_002848_peer_asset_permissions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','88005b4f-1b04-4d4f-aa02-ebe4575ceaf2'),(179,'craft','m200127_172522_queue_channels','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','5005cb71-33d1-497e-9d3e-7ff21236458e'),(180,'craft','m200211_175048_truncate_element_query_cache','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','6f8ed43d-f50a-4147-bcf7-b5f511d6b9f3'),(181,'craft','m200213_172522_new_elements_index','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','cda89ce2-f209-4efa-ab46-d471c17b6248'),(182,'craft','m200228_195211_long_deprecation_messages','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','b9a3eeb0-c734-4f0e-ba2b-8d6aafa61afb'),(183,'craft','m200306_054652_disabled_sites','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','484f05f8-9142-49c3-8372-2836a03c0f8d'),(184,'craft','m200522_191453_clear_template_caches','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','d961d07f-0c76-48d8-8e83-f13f503d50ce'),(185,'craft','m200606_231117_migration_tracks','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','c0312e17-db22-4b7f-a969-d0c6f13f6e37'),(186,'craft','m200619_215137_title_translation_method','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','061f0264-23bf-45a0-86f8-160571badf4a'),(187,'craft','m200620_005028_user_group_descriptions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9c08b7a0-7d9b-488d-a7e2-7adc84bfc485'),(188,'craft','m200620_230205_field_layout_changes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2a723e64-73c9-4c78-ba14-679c6d3b7b2e'),(189,'craft','m200625_131100_move_entrytypes_to_top_project_config','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','42c2cee0-8261-4df5-a877-6a1b58f99fca'),(190,'craft','m200629_112700_remove_project_config_legacy_files','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','3baea4e6-9d57-4cf4-a08d-b19e17ed00d9'),(191,'craft','m200630_183000_drop_configmap','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','e5edb4c8-7722-4a1d-9003-5f8df1843871'),(192,'craft','m200715_113400_transform_index_error_flag','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','3dedf11b-466a-453d-b9b7-53bf50d31c14'),(193,'craft','m200716_110900_replace_file_asset_permissions','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','8e0ddad1-e1f5-488a-b69a-f754e8d0beef'),(194,'craft','m200716_153800_public_token_settings_in_project_config','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','e0572a04-6023-4a55-858b-0d99dafc8c24'),(195,'craft','m200720_175543_drop_unique_constraints','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','eb221f39-a78e-4ff4-a27b-a690e4ed78e9'),(196,'craft','m200825_051217_project_config_version','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','ec53bf34-ad36-408b-8855-190a3275f7ec'),(197,'craft','m201116_190500_asset_title_translation_method','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','ac1896cf-13bb-4ad8-8887-4b288b7da7e0'),(198,'craft','m201124_003555_plugin_trials','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','fb5873b0-9a88-4b8c-90d8-e73b9cf4213e'),(199,'craft','m210209_135503_soft_delete_field_groups','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','511148b4-da4f-480b-b9c7-27934b95abb3'),(200,'craft','m210212_223539_delete_invalid_drafts','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','765eb3cf-1557-46f6-9392-4b6a1f427ee4'),(201,'craft','m210214_202731_track_saved_drafts','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','6cceda63-b52d-472d-801d-3f66d3684cd9'),(202,'craft','m210223_150900_add_new_element_gql_schema_components','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','5ac9a0a4-c8b1-41c8-8d1d-5e24ba89ccc5'),(203,'craft','m210302_212318_canonical_elements','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','9d937a05-6a91-4b03-bf3f-7f05c2a46646'),(204,'craft','m210326_132000_invalidate_projectconfig_cache','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','b3310a87-364d-469a-8de4-07eab4074308'),(205,'craft','m210329_214847_field_column_suffixes','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2caa95e2-3e0e-4bbc-b1f2-56983251dd35'),(206,'craft','m210331_220322_null_author','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','25449e16-5cef-42ac-a1e0-2ce0ae7df771'),(207,'craft','m210405_231315_provisional_drafts','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','fdd87c43-8a19-4585-8394-5acabd83952e'),(208,'craft','m210602_111300_project_config_names_in_config','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','d506af4b-79e7-4bc7-8da2-08f199aa689c'),(209,'craft','m210611_233510_default_placement_settings','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','2c0dda6e-7631-488c-be13-cc4b81c63c27'),(210,'craft','m210613_145522_sortable_global_sets','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','48173650-5cfa-42b1-8a40-c2df1f546e1b'),(211,'craft','m210613_184103_announcements','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','4181fc3b-4141-41ae-8e46-e8d2c0f2ccea'),(212,'craft','m210829_000000_element_index_tweak','2022-02-14 21:25:37','2022-02-14 21:25:37','2022-02-14 21:25:37','14716781-313a-4583-aa41-d46e3ffa2bf7'),(213,'craft','m220209_095604_add_indexes','2022-02-22 22:43:56','2022-02-22 22:43:56','2022-02-22 22:43:56','112f95a0-36b8-4759-8b90-362eadabed76'),(214,'craft','m220214_000000_truncate_sessions','2022-02-22 22:43:56','2022-02-22 22:43:56','2022-02-22 22:43:56','5d8d44b8-1f78-4312-8456-5e48109baab5'),(215,'craft','m210121_145800_asset_indexing_changes','2022-05-11 16:36:54','2022-05-11 16:36:54','2022-05-11 16:36:54','990ff1c7-66cd-466e-994a-5b771cf47bfc'),(216,'craft','m210624_222934_drop_deprecated_tables','2022-05-11 16:36:56','2022-05-11 16:36:56','2022-05-11 16:36:56','b917feb9-bcb9-45b7-ad18-36b55c618b73'),(217,'craft','m210724_180756_rename_source_cols','2022-05-11 16:36:56','2022-05-11 16:36:56','2022-05-11 16:36:56','4efee668-b0cc-45c6-9138-646d663d508e'),(218,'craft','m210809_124211_remove_superfluous_uids','2022-05-11 16:37:07','2022-05-11 16:37:07','2022-05-11 16:37:07','0f518894-b494-465c-8cad-8839b10ced7c'),(219,'craft','m210817_014201_universal_users','2022-05-11 16:37:17','2022-05-11 16:37:17','2022-05-11 16:37:17','d21a7dbe-88b1-440c-a0c5-cf30ea2ab85d'),(220,'craft','m210904_132612_store_element_source_settings_in_project_config','2022-05-11 16:37:17','2022-05-11 16:37:17','2022-05-11 16:37:17','fb6de67b-7094-44c1-9b71-eb598b91e32c'),(221,'craft','m211115_135500_image_transformers','2022-05-11 16:37:22','2022-05-11 16:37:22','2022-05-11 16:37:22','9b31169b-3a94-48e4-9923-e78e3d4e9b6a'),(222,'craft','m211201_131000_filesystems','2022-05-11 16:37:34','2022-05-11 16:37:34','2022-05-11 16:37:34','44a92e95-49d5-4882-a8bd-70cfa48b9b6b'),(223,'craft','m220103_043103_tab_conditions','2022-05-11 16:37:36','2022-05-11 16:37:36','2022-05-11 16:37:36','3f4e4ec6-acbf-40ac-bce6-4e4c516b3cdd'),(224,'craft','m220104_003433_asset_alt_text','2022-05-11 16:37:38','2022-05-11 16:37:38','2022-05-11 16:37:38','861a1b49-6bd3-4aaa-a9f7-e5e37ea1c5f2'),(225,'craft','m220123_213619_update_permissions','2022-05-11 16:37:38','2022-05-11 16:37:38','2022-05-11 16:37:38','d7129c7d-0772-41b7-b0f1-5c093e97cc0e'),(226,'craft','m220126_003432_addresses','2022-05-11 16:37:42','2022-05-11 16:37:42','2022-05-11 16:37:42','a2e1d424-5f54-4c67-ab07-31b03fd70949'),(227,'craft','m220213_015220_matrixblocks_owners_table','2022-05-11 16:37:49','2022-05-11 16:37:49','2022-05-11 16:37:49','accff050-2feb-4b61-b391-b3b7a70f990a'),(228,'craft','m220222_122159_full_names','2022-05-11 16:37:52','2022-05-11 16:37:52','2022-05-11 16:37:52','52f51064-094d-4413-8ced-402242e90507'),(229,'craft','m220223_180559_nullable_address_owner','2022-05-11 16:37:53','2022-05-11 16:37:53','2022-05-11 16:37:53','7bb20538-44bd-46e0-bcf2-e2f9c4473eeb'),(230,'craft','m220225_165000_transform_filesystems','2022-05-11 16:37:55','2022-05-11 16:37:55','2022-05-11 16:37:55','1d3e3395-29db-4e74-8365-cf519ef3941f'),(231,'craft','m220309_152006_rename_field_layout_elements','2022-05-11 16:37:56','2022-05-11 16:37:56','2022-05-11 16:37:56','d52f6172-8602-494d-8469-2005cc028f6e'),(232,'craft','m220314_211928_field_layout_element_uids','2022-05-11 16:37:56','2022-05-11 16:37:56','2022-05-11 16:37:56','90008614-99d6-4937-9bb1-9a31cbfb42c2'),(233,'craft','m220316_123800_transform_fs_subpath','2022-05-11 16:37:58','2022-05-11 16:37:58','2022-05-11 16:37:58','3d1c6bd3-6001-4f14-99f6-3fdd158691ae'),(234,'craft','m220317_174250_release_all_jobs','2022-05-11 16:37:58','2022-05-11 16:37:58','2022-05-11 16:37:58','7c1210b5-73c4-414a-ab4e-07a41bd10ad7'),(235,'craft','m220330_150000_add_site_gql_schema_components','2022-05-11 16:37:58','2022-05-11 16:37:58','2022-05-11 16:37:58','8d0a402b-b7ad-4685-a9a2-cd745f05ee7b'),(236,'craft','m220413_024536_site_enabled_string','2022-05-11 16:38:01','2022-05-11 16:38:01','2022-05-11 16:38:01','01b2a672-c955-4a35-a0f3-67be411ce97c'),(240,'plugin:redactor','m180430_204710_remove_old_plugins','2022-05-13 19:33:19','2022-05-13 19:33:20','2022-05-13 19:33:20','791802a7-0a1a-45b9-a041-a60372e331dc'),(241,'plugin:redactor','Install','2022-05-13 19:33:20','2022-05-13 19:33:20','2022-05-13 19:33:20','f44c0ac9-afd7-4c28-a229-10c076781ff8'),(242,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2022-05-13 19:33:20','2022-05-13 19:33:20','2022-05-13 19:33:20','a629cc8b-e405-4abf-8310-ffd1354f9005'),(243,'plugin:express-forms','Install','2022-05-16 09:51:51','2022-05-16 09:51:52','2022-05-16 09:51:52','9bd34879-ed46-4e7e-9fd3-a31c5f692f0e'),(244,'plugin:express-forms','m190417_182337_ChangeResourceFieldUniqueIndex','2022-05-16 09:51:52','2022-05-16 09:51:52','2022-05-16 09:51:52','f287ddf6-4bdc-4a83-8789-819ea5393964');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `schemaVersion` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nebyvuivlzxnudikhpzebzgujzidpjqsvytw` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (4,'seo','4.0.0','3.2.0','unknown',NULL,'2022-02-14 21:25:34','2022-02-14 21:25:34','2022-05-23 19:28:35','fa9b6dd8-561c-49ba-8332-356b962b0591'),(6,'dumper','3.0.0','1.0.0','unknown',NULL,'2022-05-09 08:29:53','2022-05-09 08:29:53','2022-05-23 19:28:35','a0d72a7c-ba9a-43ff-b59a-0f399f620d07'),(7,'elements-panel','2.0.0','1.0.0','unknown',NULL,'2022-05-09 08:30:57','2022-05-09 08:30:57','2022-05-23 19:28:35','e5f1fab6-eb2e-4f43-882b-033f26d8f718'),(9,'redactor','3.0.0','2.3.0','unknown',NULL,'2022-05-13 19:33:19','2022-05-13 19:33:19','2022-05-23 19:28:35','ebbe02ec-ce4e-4163-8a9f-224abe5b1f5c'),(10,'express-forms','2.0.0-beta.1','1.0.1','unknown',NULL,'2022-05-16 09:51:37','2022-05-16 09:51:37','2022-05-23 19:28:35','3a7940d9-2241-4167-b1b0-a55e44dca05c');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.defaultPlacement','\"end\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.autocapitalize','true'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.autocomplete','false'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.autocorrect','true'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.class','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.disabled','false'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.id','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.instructions','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.label','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.max','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.min','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.name','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.orientation','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.placeholder','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.readonly','false'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.requirable','false'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.size','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.step','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.tip','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.title','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.uid','\"820a6a9e-fc03-4e5a-baea-a50970939e2c\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.warning','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.0.width','100'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.fieldUid','\"5efbbd6a-2d8b-4ef0-b03a-1bf53718f687\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.instructions','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.label','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.required','false'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.tip','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.uid','\"f2c5067c-76c1-4fee-9b0a-58c8627b97c5\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.warning','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.elements.1.width','100'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.name','\"Content\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.fieldLayouts.f4c858c9-307a-4cff-9f34-412de984cc39.tabs.0.uid','\"83ca09db-3144-47ae-9db0-c3ed02d08e2a\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.handle','\"blogCategories\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.name','\"Blog Categories\"'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.hasUrls','false'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.template','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.uriFormat','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.hasUrls','false'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.template','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.uriFormat','null'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.structure.maxLevels','1'),('categoryGroups.541a135e-c132-4a7f-b2ef-9869b60caba3.structure.uid','\"4641dbd1-76ee-44b0-ab32-bb5f902609b0\"'),('dateModified','1653225232'),('elementSources.craft\\elements\\Entry.0.disabled','false'),('elementSources.craft\\elements\\Entry.0.key','\"*\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.0','\"section\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.1','\"dateCreated\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.2','\"dateUpdated\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.3','\"link\"'),('elementSources.craft\\elements\\Entry.0.type','\"native\"'),('elementSources.craft\\elements\\Entry.1.disabled','false'),('elementSources.craft\\elements\\Entry.1.key','\"singles\"'),('elementSources.craft\\elements\\Entry.1.tableAttributes.0','\"dateCreated\"'),('elementSources.craft\\elements\\Entry.1.tableAttributes.1','\"dateUpdated\"'),('elementSources.craft\\elements\\Entry.1.tableAttributes.2','\"link\"'),('elementSources.craft\\elements\\Entry.1.type','\"native\"'),('elementSources.craft\\elements\\Entry.2.disabled','false'),('elementSources.craft\\elements\\Entry.2.key','\"section:1fa133fd-47b8-4acc-857d-b9677a729349\"'),('elementSources.craft\\elements\\Entry.2.tableAttributes.0','\"dateCreated\"'),('elementSources.craft\\elements\\Entry.2.tableAttributes.1','\"dateUpdated\"'),('elementSources.craft\\elements\\Entry.2.tableAttributes.2','\"link\"'),('elementSources.craft\\elements\\Entry.2.type','\"native\"'),('elementSources.craft\\elements\\Entry.3.disabled','false'),('elementSources.craft\\elements\\Entry.3.key','\"section:1c008561-0013-4b4d-b04a-f51a038c5a20\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.0','\"dateCreated\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.1','\"dateUpdated\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.2','\"link\"'),('elementSources.craft\\elements\\Entry.3.type','\"native\"'),('email.fromEmail','\"$CRAFT_EMAIL\"'),('email.fromName','\"$CRAFT_SITE_NAME\"'),('email.replyToEmail','\"$CRAFT_EMAIL\"'),('email.template','null'),('email.transportSettings.command','\"/usr/sbin/sendmail -bs\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.autocapitalize','true'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.autocomplete','false'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.autocorrect','true'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.class','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.disabled','false'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.id','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.instructions','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.label','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.max','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.min','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.name','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.orientation','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.placeholder','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.readonly','false'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.requirable','false'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.size','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.step','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.tip','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.title','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.warning','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.elements.0.width','100'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.name','\"Content\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.0.sortOrder','1'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.fieldUid','\"db74e3e8-29b2-475d-bbae-ff18672720f1\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.instructions','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.label','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.required','false'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.tip','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.warning','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.elements.0.width','100'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.name','\"SEO\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.fieldLayouts.1a58eba3-7362-47c6-891d-4b0129387ba9.tabs.1.sortOrder','2'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.handle','\"pages\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.hasTitleField','true'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.name','\"Pages\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.section','\"1fa133fd-47b8-4acc-857d-b9677a729349\"'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.sortOrder','1'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.titleFormat','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.titleTranslationKeyFormat','null'),('entryTypes.4873fd21-756a-4934-ac48-7b6f5d2d0087.titleTranslationMethod','\"site\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.autocapitalize','true'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.autocomplete','false'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.autocorrect','true'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.class','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.disabled','false'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.id','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.instructions','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.label','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.max','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.min','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.name','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.orientation','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.placeholder','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.readonly','false'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.requirable','false'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.size','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.step','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.tip','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.title','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.warning','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.elements.0.width','100'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.name','\"Content\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.0.sortOrder','1'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.fieldUid','\"db74e3e8-29b2-475d-bbae-ff18672720f1\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.instructions','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.label','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.required','false'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.tip','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.warning','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.elements.0.width','100'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.name','\"SEO\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.fieldLayouts.c362e989-1d89-4904-b246-aa142e0d248c.tabs.1.sortOrder','2'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.handle','\"contact\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.hasTitleField','true'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.name','\"Contact\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.section','\"7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.sortOrder','1'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.titleFormat','\"{section.name|raw}\"'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.titleTranslationKeyFormat','null'),('entryTypes.a209a002-c58f-4520-b709-cd52a88e9d6b.titleTranslationMethod','\"site\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.autocapitalize','true'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.autocomplete','false'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.autocorrect','true'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.class','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.disabled','false'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.id','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.instructions','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.label','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.max','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.min','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.name','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.orientation','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.placeholder','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.readonly','false'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.requirable','false'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.size','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.step','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.tip','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.title','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.warning','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.elements.0.width','100'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.name','\"Content\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.0.sortOrder','1'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.fieldUid','\"db74e3e8-29b2-475d-bbae-ff18672720f1\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.instructions','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.label','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.required','false'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.tip','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.warning','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.elements.0.width','100'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.name','\"SEO\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.fieldLayouts.d4a70594-89a4-4579-9d07-2e6aa3695778.tabs.1.sortOrder','2'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.handle','\"home\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.hasTitleField','true'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.name','\"Home\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.section','\"93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.sortOrder','1'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.titleFormat','\"{section.name|raw}\"'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.titleTranslationKeyFormat','null'),('entryTypes.a57a7266-7418-4d78-af8e-3a3950389f39.titleTranslationMethod','\"site\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.autocapitalize','true'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.autocomplete','false'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.autocorrect','true'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.class','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.disabled','false'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.id','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.instructions','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.label','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.max','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.min','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.name','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.orientation','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.placeholder','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.readonly','false'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.requirable','false'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.size','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.step','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.tip','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.title','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.uid','\"3aae76fb-1dc4-4fd1-bff1-5a09435c7757\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.warning','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.0.width','100'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.fieldUid','\"51c27d0d-e6ac-45ab-92e4-4e2eb69766ff\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.instructions','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.label','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.required','false'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.tip','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.uid','\"deadc17f-1180-4962-bcd7-a3b673a5ec5c\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.warning','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.elements.1.width','100'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.name','\"Content\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.0.uid','\"c37427ee-2bb9-426b-977f-cfbb91ff525e\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.fieldUid','\"db74e3e8-29b2-475d-bbae-ff18672720f1\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.instructions','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.label','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.required','false'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.tip','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.uid','\"c6e33ff7-fa24-4b4d-8093-ad209f66b043\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.warning','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.elements.0.width','100'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.name','\"SEO\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.fieldLayouts.083ce270-97f8-4d12-910d-8beeb83aa17e.tabs.1.uid','\"3403ffe2-6deb-4d35-8277-86fa3238c4d0\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.handle','\"blog\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.hasTitleField','true'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.name','\"Blog\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.section','\"9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.sortOrder','1'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.titleFormat','\"{section.name|raw}\"'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.titleTranslationKeyFormat','null'),('entryTypes.e9963072-edc2-4605-bc24-39a15f9ccc35.titleTranslationMethod','\"site\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.autocapitalize','true'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.autocomplete','false'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.autocorrect','true'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.class','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.disabled','false'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.id','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.instructions','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.label','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.max','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.min','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.name','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.orientation','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.placeholder','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.readonly','false'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.requirable','false'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.size','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.step','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.tip','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.title','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.uid','\"c1807e1b-ca51-46b8-a1bd-df70a2557eea\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.warning','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.0.width','100'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.fieldUid','\"2b5c3999-f111-4535-8ecd-a81e95483d94\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.instructions','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.label','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.required','false'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.tip','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.uid','\"c2ee051a-7c82-44b3-a125-9bfc9b78feb7\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.warning','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.elements.1.width','100'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.name','\"Content\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.0.uid','\"d0e34251-965c-4e68-adb6-6e3821aee376\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.fieldUid','\"db74e3e8-29b2-475d-bbae-ff18672720f1\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.instructions','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.label','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.required','false'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.tip','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.uid','\"3b835e2e-d029-4932-b2e3-547bd4712d92\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.warning','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.elements.0.width','100'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.name','\"SEO\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.fieldLayouts.4c158bd5-b386-4482-b8c7-d6a51c6d64fb.tabs.1.uid','\"d9d938d9-f19a-400b-ad0f-79ef99f17837\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.handle','\"default\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.hasTitleField','true'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.name','\"Default\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.section','\"1c008561-0013-4b4d-b04a-f51a038c5a20\"'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.sortOrder','1'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.titleFormat','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.titleTranslationKeyFormat','null'),('entryTypes.f3c09b26-065d-4c42-b4a6-2665764ec9fa.titleTranslationMethod','\"site\"'),('fieldGroups.6bb82573-3aa5-4763-b4ca-603601dce3d2.name','\"Global\"'),('fieldGroups.6e6e5ab5-ec46-433d-80af-42840709af85.name','\"Common\"'),('fieldGroups.7e985e9f-e680-483b-8355-eaa0ffe93374.name','\"Blog\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.columnSuffix','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.contentColumnType','\"string\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.fieldGroup','\"7e985e9f-e680-483b-8355-eaa0ffe93374\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.handle','\"blogCategory\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.instructions','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.name','\"Blog Category\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.searchable','false'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.allowLimit','false'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.allowMultipleSources','false'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.allowSelfRelations','false'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.branchLimit','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.localizeRelations','false'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.maxRelations','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.minRelations','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.selectionLabel','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.showSiteMenu','false'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.source','\"group:541a135e-c132-4a7f-b2ef-9869b60caba3\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.sources','\"*\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.targetSiteId','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.validateRelatedElements','false'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.settings.viewMode','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.translationKeyFormat','null'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.translationMethod','\"site\"'),('fields.2b5c3999-f111-4535-8ecd-a81e95483d94.type','\"craft\\\\fields\\\\Categories\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.columnSuffix','null'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.contentColumnType','\"string\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.fieldGroup','\"6e6e5ab5-ec46-433d-80af-42840709af85\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.handle','\"banner\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.instructions','null'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.name','\"Banner\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.searchable','false'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.settings.contentTable','\"{{%matrixcontent_banner}}\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.settings.maxBlocks','1'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.settings.minBlocks','1'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.settings.propagationKeyFormat','null'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.settings.propagationMethod','\"all\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.translationKeyFormat','null'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.translationMethod','\"site\"'),('fields.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff.type','\"craft\\\\fields\\\\Matrix\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.columnSuffix','\"ayvjetxk\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.contentColumnType','\"string\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.fieldGroup','\"7e985e9f-e680-483b-8355-eaa0ffe93374\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.handle','\"blogCategoryColor\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.instructions','\"\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.name','\"Blog Category Color\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.searchable','false'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.optgroups','true'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.0.__assoc__.0.0','\"label\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.0.__assoc__.0.1','\"Red\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.0.__assoc__.1.0','\"value\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.0.__assoc__.1.1','\"red\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.0.__assoc__.2.0','\"default\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.0.__assoc__.2.1','\"\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.1.__assoc__.0.0','\"label\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.1.__assoc__.0.1','\"Orange\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.1.__assoc__.1.0','\"value\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.1.__assoc__.1.1','\"orange\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.1.__assoc__.2.0','\"default\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.1.__assoc__.2.1','\"\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.2.__assoc__.0.0','\"label\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.2.__assoc__.0.1','\"Green\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.2.__assoc__.1.0','\"value\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.2.__assoc__.1.1','\"green\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.2.__assoc__.2.0','\"default\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.2.__assoc__.2.1','\"\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.3.__assoc__.0.0','\"label\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.3.__assoc__.0.1','\"Blue\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.3.__assoc__.1.0','\"value\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.3.__assoc__.1.1','\"blue\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.3.__assoc__.2.0','\"default\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.3.__assoc__.2.1','\"\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.4.__assoc__.0.0','\"label\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.4.__assoc__.0.1','\"Purple\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.4.__assoc__.1.0','\"value\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.4.__assoc__.1.1','\"purple\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.4.__assoc__.2.0','\"default\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.4.__assoc__.2.1','\"\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.5.__assoc__.0.0','\"label\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.5.__assoc__.0.1','\"Pink\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.5.__assoc__.1.0','\"value\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.5.__assoc__.1.1','\"pink\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.5.__assoc__.2.0','\"default\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.settings.options.5.__assoc__.2.1','\"\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.translationKeyFormat','null'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.translationMethod','\"none\"'),('fields.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.columnSuffix','\"xicqkdxc\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.contentColumnType','\"text\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.fieldGroup','\"6e6e5ab5-ec46-433d-80af-42840709af85\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.handle','\"seo\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.instructions','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.name','\"SEO\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.searchable','false'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.description','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.hideSocial','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.robots.0','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.robots.1','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.robots.2','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.robots.3','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.robots.4','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.robots.5','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.socialImage','\"\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.suffixAsPrefix','null'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.0.__assoc__.0.0','\"key\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.0.__assoc__.0.1','\"1\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.0.__assoc__.1.0','\"locked\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.0.__assoc__.1.1','\"0\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.0.__assoc__.2.0','\"template\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.0.__assoc__.2.1','\"{title}\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.1.__assoc__.0.0','\"key\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.1.__assoc__.0.1','\"2\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.1.__assoc__.1.0','\"locked\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.1.__assoc__.1.1','\"1\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.1.__assoc__.2.0','\"template\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.title.1.__assoc__.2.1','\" - {{ currentSite.group.name }}\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.settings.titleSuffix','null'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.translationKeyFormat','null'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.translationMethod','\"site\"'),('fields.db74e3e8-29b2-475d-bbae-ff18672720f1.type','\"ether\\\\seo\\\\fields\\\\SeoField\"'),('fs.main.hasUrls','true'),('fs.main.name','\"Main\"'),('fs.main.settings.path','\"@assets_path\"'),('fs.main.type','\"craft\\\\fs\\\\Local\"'),('fs.main.url','\"@assets_base\"'),('globalSets.2d0fb778-2d78-49c0-b94d-740200560f8f.handle','\"navigation\"'),('globalSets.2d0fb778-2d78-49c0-b94d-740200560f8f.name','\"Navigation\"'),('globalSets.2d0fb778-2d78-49c0-b94d-740200560f8f.sortOrder','1'),('graphql.publicToken.enabled','true'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.5a91ab6b-5698-4382-8d79-9b7c950b67f4.isPublic','true'),('graphql.schemas.5a91ab6b-5698-4382-8d79-9b7c950b67f4.name','\"Public Schema\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.field','\"51c27d0d-e6ac-45ab-92e4-4e2eb69766ff\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.fieldUid','\"e3e8dd6d-7223-4e6c-b085-4d618b2671b0\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.label','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.required','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.tip','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.uid','\"771d5abb-beb2-41d2-a150-6e6c9460a928\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.warning','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.0.width','100'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.fieldUid','\"9a81afee-7773-471a-8523-952141569d38\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.label','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.required','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.tip','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.uid','\"7542e498-f8ca-4a62-a427-8e7f122f8618\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.warning','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.elements.1.width','100'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.name','\"Content\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fieldLayouts.c9465fac-b4f2-410d-9cd3-c60cffd825a3.tabs.0.uid','\"4515fdce-f496-4d1c-af29-2b2ea6de5f11\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.columnSuffix','\"nfdgofga\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.contentColumnType','\"text\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.fieldGroup','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.handle','\"body\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.instructions','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.name','\"Body\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.searchable','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.availableTransforms','\"*\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.availableVolumes','\"*\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.columnType','\"text\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.configSelectionMode','\"choose\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.defaultTransform','\"\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.manualConfig','\"\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.purifierConfig','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.purifyHtml','true'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.redactorConfig','\"Simple.json\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.removeEmptyTags','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.removeInlineStyles','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.removeNbsp','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.showHtmlButtonForNonAdmins','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.showUnpermittedFiles','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.settings.uiMode','\"enlarged\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.translationKeyFormat','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.translationMethod','\"none\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.9a81afee-7773-471a-8523-952141569d38.type','\"craft\\\\redactor\\\\Field\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.columnSuffix','\"hauxjttk\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.contentColumnType','\"text\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.fieldGroup','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.handle','\"titel\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.instructions','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.name','\"Titel\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.searchable','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.byteLimit','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.charLimit','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.code','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.columnType','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.initialRows','4'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.multiline','false'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.placeholder','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.settings.uiMode','\"normal\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.translationKeyFormat','null'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.translationMethod','\"none\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.fields.e3e8dd6d-7223-4e6c-b085-4d618b2671b0.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.handle','\"banner\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.name','\"Banner\"'),('matrixBlockTypes.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8.sortOrder','1'),('meta.__names__.005e684f-7b7c-4ad0-9833-7c86852558f7','\"Custom\"'),('meta.__names__.051d5b55-8d14-441c-9e97-81e02250c265','\"Custom\"'),('meta.__names__.15174f4c-d3be-48dc-900e-91442b621f06','\"Entry\"'),('meta.__names__.1c008561-0013-4b4d-b04a-f51a038c5a20','\"Blog - Items\"'),('meta.__names__.1fa133fd-47b8-4acc-857d-b9677a729349','\"Pages\"'),('meta.__names__.2715fef6-bec1-4a6f-b3df-6c6e0f75fdb8','\"Banner\"'),('meta.__names__.2b5c3999-f111-4535-8ecd-a81e95483d94','\"Blog Category\"'),('meta.__names__.2d0fb778-2d78-49c0-b94d-740200560f8f','\"Navigation\"'),('meta.__names__.447b1110-2c9a-4975-80e5-fcde89668553','\"Passive Title\"'),('meta.__names__.4873fd21-756a-4934-ac48-7b6f5d2d0087','\"Pages\"'),('meta.__names__.4c265acc-11f0-466c-81c1-c43c5cfa3eb9','\"Entry\"'),('meta.__names__.4d8ac26f-0eed-4e84-8f0f-fb59450142e3','\"English\"'),('meta.__names__.51c27d0d-e6ac-45ab-92e4-4e2eb69766ff','\"Banner\"'),('meta.__names__.53d85414-54dd-4826-93f5-7de22f9bde8c','\"Entry\"'),('meta.__names__.541a135e-c132-4a7f-b2ef-9869b60caba3','\"Blog Categories\"'),('meta.__names__.5a91ab6b-5698-4382-8d79-9b7c950b67f4','\"Public Schema\"'),('meta.__names__.5efbbd6a-2d8b-4ef0-b03a-1bf53718f687','\"Blog Category Color\"'),('meta.__names__.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf','\"Main\"'),('meta.__names__.67f102fe-cbe0-438a-8e71-e1f062609695','\"Entry\"'),('meta.__names__.6bb82573-3aa5-4763-b4ca-603601dce3d2','\"Global\"'),('meta.__names__.6e6e5ab5-ec46-433d-80af-42840709af85','\"Common\"'),('meta.__names__.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2','\"Contact\"'),('meta.__names__.75d9dd9c-34cd-4041-8eaa-6de7733332b6','\"Custom Title\"'),('meta.__names__.76f56d28-6f60-4b6a-97dd-6f07b22ac710','\"Passive\"'),('meta.__names__.796b6a3e-2cbd-4359-8c33-3c5411a4112c','\"Custom URL\"'),('meta.__names__.7e985e9f-e680-483b-8355-eaa0ffe93374','\"Blog\"'),('meta.__names__.9193b8e5-9e85-4ad6-9dfc-17f0a0c77968','\"test\"'),('meta.__names__.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68','\"Home\"'),('meta.__names__.9a81afee-7773-471a-8523-952141569d38','\"Body\"'),('meta.__names__.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d','\"Blog\"'),('meta.__names__.a209a002-c58f-4520-b709-cd52a88e9d6b','\"Contact\"'),('meta.__names__.a57a7266-7418-4d78-af8e-3a3950389f39','\"Home\"'),('meta.__names__.c3ab0099-2bd0-4fb3-9f99-0b7ef05a796d','\"Custom URL\"'),('meta.__names__.cfa92a12-d5a1-41d8-b55e-8678206d6977','\"Passive\"'),('meta.__names__.db74e3e8-29b2-475d-bbae-ff18672720f1','\"SEO\"'),('meta.__names__.e3e8dd6d-7223-4e6c-b085-4d618b2671b0','\"Titel\"'),('meta.__names__.e9963072-edc2-4605-bc24-39a15f9ccc35','\"Blog\"'),('meta.__names__.ebf5391a-5427-4f9f-ad74-cf0abc48ad23','\"Custom Title\"'),('meta.__names__.f3c09b26-065d-4c42-b4a6-2665764ec9fa','\"Default\"'),('meta.__names__.f4e1bac5-a983-4505-91d2-5a26971ad491','\"Passive Title\"'),('meta.__names__.f5399107-84c7-4af5-8764-8c333d1b9ebc','\"Dutch\"'),('meta.__names__.fd05975e-1963-4ddd-8f7b-57678dbe0ac6','\"$CRAFT_SITE_NAME\"'),('plugins.dumper.edition','\"standard\"'),('plugins.dumper.enabled','true'),('plugins.dumper.schemaVersion','\"1.0.0\"'),('plugins.elements-panel.edition','\"standard\"'),('plugins.elements-panel.enabled','true'),('plugins.elements-panel.schemaVersion','\"1.0.0\"'),('plugins.express-forms.edition','\"lite\"'),('plugins.express-forms.enabled','true'),('plugins.express-forms.schemaVersion','\"1.0.1\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('plugins.seo.edition','\"standard\"'),('plugins.seo.enabled','true'),('plugins.seo.schemaVersion','\"3.2.0\"'),('plugins.seo.settings.description','\"\"'),('plugins.seo.settings.facebookAppId','\"\"'),('plugins.seo.settings.metaTemplate','\"\"'),('plugins.seo.settings.removeAlternateUrls','\"\"'),('plugins.seo.settings.robots.0','\"\"'),('plugins.seo.settings.robots.1','\"\"'),('plugins.seo.settings.robots.2','\"\"'),('plugins.seo.settings.robots.3','\"\"'),('plugins.seo.settings.robots.4','\"\"'),('plugins.seo.settings.robots.5','\"\"'),('plugins.seo.settings.robotsTxt','\"{# Sitemap URL #}\\r\\nSitemap: {{ url(seo.sitemapName ~ \'.xml\') }}\\r\\n\\r\\n{# Disallows #}\\r\\n{% if craft.app.config.env != \'production\' %}\\r\\n\\r\\n{# Disallow access to everything when NOT in production #}\\r\\nUser-agent: *\\r\\nDisallow: /\\r\\n\\r\\n{% else %}\\r\\n\\r\\n{# Disallow access to cpresources/ when live #}\\r\\nUser-agent: *\\r\\nDisallow: /cpresources/\\r\\n\\r\\n{% endif %}\"'),('plugins.seo.settings.sitemapLimit','\"1000\"'),('plugins.seo.settings.sitemapName','\"sitemap\"'),('plugins.seo.settings.socialImage','\"\"'),('plugins.seo.settings.title.0.__assoc__.0.0','\"key\"'),('plugins.seo.settings.title.0.__assoc__.0.1','\"1\"'),('plugins.seo.settings.title.0.__assoc__.1.0','\"locked\"'),('plugins.seo.settings.title.0.__assoc__.1.1','\"0\"'),('plugins.seo.settings.title.0.__assoc__.2.0','\"template\"'),('plugins.seo.settings.title.0.__assoc__.2.1','\"{title}\"'),('plugins.seo.settings.title.1.__assoc__.0.0','\"key\"'),('plugins.seo.settings.title.1.__assoc__.0.1','\"2\"'),('plugins.seo.settings.title.1.__assoc__.1.0','\"locked\"'),('plugins.seo.settings.title.1.__assoc__.1.1','\"1\"'),('plugins.seo.settings.title.1.__assoc__.2.0','\"template\"'),('plugins.seo.settings.title.1.__assoc__.2.1','\" - {{ currentSite.group.name }}\"'),('plugins.seo.settings.titleSuffix','null'),('plugins.seo.settings.twitterHandle','\"\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.defaultPlacement','\"end\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.enableVersioning','true'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.handle','\"blogItems\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.name','\"Blog - Items\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.propagationMethod','\"all\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.enabledByDefault','true'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.hasUrls','true'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.template','\"_blog/entry\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.uriFormat','\"{{ craft.entries.section(\'blog\').one.slug }}/{slug}\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.enabledByDefault','true'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.hasUrls','true'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.template','\"_blog/entry\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.uriFormat','\"{{ craft.entries.section(\'blog\').one.slug }}/{slug}\"'),('sections.1c008561-0013-4b4d-b04a-f51a038c5a20.type','\"channel\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.defaultPlacement','\"end\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.enableVersioning','true'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.handle','\"pages\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.name','\"Pages\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.propagationMethod','\"all\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.enabledByDefault','true'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.hasUrls','true'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.template','\"_pages\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.uriFormat','\"{slug}\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.enabledByDefault','true'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.hasUrls','true'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.template','\"_pages\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.uriFormat','\"{slug}\"'),('sections.1fa133fd-47b8-4acc-857d-b9677a729349.type','\"channel\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.defaultPlacement','\"end\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.enableVersioning','true'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.handle','\"contact\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.name','\"Contact\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.propagationMethod','\"all\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.enabledByDefault','true'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.hasUrls','true'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.template','\"_contact/index.twig\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.uriFormat','\"{slug}\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.enabledByDefault','true'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.hasUrls','true'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.template','\"_contact/index.twig\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.uriFormat','\"{slug}\"'),('sections.7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2.type','\"single\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.defaultPlacement','\"end\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.enableVersioning','true'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.handle','\"home\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.name','\"Home\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.propagationMethod','\"all\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.enabledByDefault','true'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.hasUrls','true'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.template','\"index\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.uriFormat','\"__home__\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.enabledByDefault','true'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.hasUrls','true'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.template','\"index\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.uriFormat','\"__home__\"'),('sections.93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68.type','\"single\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.defaultPlacement','\"end\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.enableVersioning','true'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.handle','\"blog\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.name','\"Blog\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.propagationMethod','\"all\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.enabledByDefault','true'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.hasUrls','true'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.template','\"_blog/index.twig\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.uriFormat','\"{slug}\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.enabledByDefault','true'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.hasUrls','true'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.template','\"_blog/index.twig\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.siteSettings.f5399107-84c7-4af5-8764-8c333d1b9ebc.uriFormat','\"{slug}\"'),('sections.9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d.type','\"single\"'),('siteGroups.fd05975e-1963-4ddd-8f7b-57678dbe0ac6.name','\"$CRAFT_SITE_NAME\"'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.baseUrl','\"@web\"'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.enabled','true'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.handle','\"English\"'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.hasUrls','true'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.language','\"en\"'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.name','\"English\"'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.primary','true'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.siteGroup','\"fd05975e-1963-4ddd-8f7b-57678dbe0ac6\"'),('sites.4d8ac26f-0eed-4e84-8f0f-fb59450142e3.sortOrder','1'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.baseUrl','\"@web_nl\"'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.enabled','\"1\"'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.handle','\"dutch\"'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.hasUrls','true'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.language','\"nl\"'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.name','\"Dutch\"'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.primary','false'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.siteGroup','\"fd05975e-1963-4ddd-8f7b-57678dbe0ac6\"'),('sites.f5399107-84c7-4af5-8764-8c333d1b9ebc.sortOrder','2'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"$CRAFT_SITE_NAME\"'),('system.retryDuration','null'),('system.schemaVersion','\"4.0.0.9\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.deactivateByDefault','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.autocapitalize','true'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.autocomplete','false'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.autocorrect','true'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.class','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.disabled','false'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.id','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.instructions','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.label','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.max','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.min','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.name','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.orientation','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.placeholder','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.readonly','false'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.requirable','false'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.size','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.step','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.tip','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.title','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.uid','\"ad022d95-31c5-4f14-a660-8167e0ff4755\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.warning','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.elements.0.width','100'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.name','\"Content\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fieldLayouts.ed0618ae-16b1-40e7-b501-f1c7feb9e0a4.tabs.0.uid','\"bc8d02a4-f2b7-4351-bdeb-899a174d267d\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.fs','\"main\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.handle','\"main\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.name','\"Main\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.sortOrder','1'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.titleTranslationKeyFormat','null'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.titleTranslationMethod','\"site\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.transformFs','\"\"'),('volumes.5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf.transformSubpath','\"_transforms\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_lskvbuzrrquzrlvbhlhgsuymubntundjbwqs` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_hkoldwqcfwuqdzcivngdriyhmvmmnvfmarqy` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=280 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lekdhzhtbsbwxiaoyazgcqaqlqqdcdwmrkoh` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_mlpwxfgpejhllmwgjilrpyybhjiaoucysbny` (`sourceId`),
  KEY `idx_keecprrutcnzbvwknlieughnlopzhdlxnrkr` (`targetId`),
  KEY `idx_ztetcmmsfaruosnkqvwfajmhjqrjoltupdlk` (`sourceSiteId`),
  CONSTRAINT `fk_bpdjckiwyxpnlkwoeifrwjmtqaryrgyyegab` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nthrotmlzzkzdndpxmyvymbbdofckmcjrxqk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rzxiluvoudkwydbgxhxemludozavcforoian` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_szinjuhxkfdjznlherouhzuqjkhdwtzdqskm` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (2,9,32,NULL,42,1,'2022-05-22 13:13:56','2022-05-22 13:13:56','f741dbfe-d727-4456-a79a-f14474583a2a'),(3,9,55,NULL,42,1,'2022-05-22 13:13:57','2022-05-22 13:13:57','093757f5-20de-45c8-a98d-a1a3abca30cd'),(4,9,56,NULL,42,1,'2022-05-22 13:20:48','2022-05-22 13:20:48','1d4ef997-f56a-41b4-858e-879b0b369a30');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('117f8314','@craft/web/assets/sites/dist'),('1229031d','@craft/web/assets/picturefill/dist'),('153f4dc8','@craft/web/assets/iframeresizer/dist'),('17217c7c','@craft/web/assets/admintable/dist'),('173aeffc','@craft/web/assets/generalsettings/dist'),('1991be1d','@craft/web/assets/xregexp/dist'),('1bf569d9','@craft/web/assets/craftsupport/dist'),('1e0f84a9','@craft/web/assets/fields/dist'),('1e15bba7','@craft/web/assets/updateswidget/dist'),('1e5e447f','@craft/web/assets/d3/dist'),('1f8d8709','@craft/web/assets/fabric/dist'),('20aff9c9','@craft/web/assets/recententries/dist'),('2be5db74','@craft/web/assets/velocity/dist'),('2e1d0894','@craft/web/assets/fabric/dist'),('2e2106a1','@craft/web/assets/jquerytouchevents/dist'),('2e72d9c3','@craft/web/assets/jquerypayment/dist'),('373fb01e','@craft/web/assets/garnish/dist'),('385a6c90','@craft/web/assets/axios/dist'),('3944af62','@craft/web/assets/plugins/dist'),('40013d9f','@craft/web/assets/recententries/dist'),('4041c8df','@craft/web/assets/sites/dist'),('4268d335','@craft/web/assets/fieldsettings/dist'),('44010603','@craft/web/assets/iframeresizer/dist'),('4604a437','@craft/web/assets/generalsettings/dist'),('46b6236','@craft/web/assets/cp/dist'),('49c27bc0','@craft/web/assets/updater/dist'),('4eb3ccc2','@craft/web/assets/fabric/dist'),('4f2bf06c','@craft/web/assets/updateswidget/dist'),('4f600fb4','@craft/web/assets/d3/dist'),('51810bb0','@craft/web/assets/upgrade/dist'),('555529fd','@craft/web/assets/cp/dist'),('57ae9a66','@craft/web/assets/focusvisible/dist'),('5829722b','@craft/web/assets/installer/dist'),('58f4a8c6','@craft/web/assets/axios/dist'),('591d8bb5','@craft/web/assets/selectize/dist'),('5c2e1980','@craft/web/assets/pluginstore/dist'),('5da37256','@craft/web/assets/dashboard/dist'),('5e083197','@craft/web/assets/tailwindreset/dist'),('5e995afc','@craft/web/assets/utilities/dist'),('64c5a660','@craft/web/assets/cp/dist'),('6601fbd5','@craft/web/assets/garnish/dist'),('663e15fb','@craft/web/assets/focusvisible/dist'),('688d0428','@craft/web/assets/selectize/dist'),('690d1ad','@craft/web/assets/focusvisible/dist'),('6964275b','@craft/web/assets/axios/dist'),('6af3f83','@craft/web/assets/garnish/dist'),('6c4034b6','@craft/web/assets/fileupload/dist'),('6dbe961d','@craft/web/assets/pluginstore/dist'),('7191b202','@craft/web/assets/recententries/dist'),('7216da56','@craft/web/assets/conditionbuilder/dist'),('723be21d','@craft/web/assets/jqueryui/dist'),('73f85ca8','@craft/web/assets/fieldsettings/dist'),('7591899e','@craft/web/assets/iframeresizer/dist'),('778fb82a','@craft/web/assets/admintable/dist'),('7852f45d','@craft/web/assets/updater/dist'),('78dc720b','@bower/jquery/dist'),('7d3c6de3','@craft/web/assets/elementresizedetector/dist'),('7ebb7ff1','@craft/web/assets/updateswidget/dist'),('7ef08029','@craft/web/assets/d3/dist'),('81498da1','@craft/web/assets/jqueryui/dist'),('823c07e','@craft/web/assets/selectize/dist'),('82e3ddbe','@craft/web/assets/recententries/dist'),('86ac70ea','@craft/web/assets/feed/dist'),('89a9ff03','@craft/web/assets/velocity/dist'),('8b209be1','@craft/web/assets/updater/dist'),('8bae1db7','@bower/jquery/dist'),('8c3efdb4','@craft/web/assets/jquerypayment/dist'),('8c6d22d6','@craft/web/assets/jquerytouchevents/dist'),('8e4e025f','@craft/web/assets/elementresizedetector/dist'),('970042bc','@craft/web/assets/updates/dist'),('9a1648e7','@craft/web/assets/axios/dist'),('9a786d07','@Solspace/ExpressForms/resources'),('9d892758','@craft/web/assets/vue/dist'),('9f325b0a','@craft/web/assets/fileupload/dist'),('9f419277','@craft/web/assets/dashboard/dist'),('a4dcf5da','@craft/web/assets/focusvisible/dist'),('a6274641','@craft/web/assets/cp/dist'),('aa6fe409','@craft/web/assets/selectize/dist'),('aea2d497','@craft/web/assets/fileupload/dist'),('aed11dea','@craft/web/assets/dashboard/dist'),('b065276a','@craft/web/assets/picturefill/dist'),('b0d9023c','@craft/web/assets/jqueryui/dist'),('b11bfe86','@craft/web/assets/matrixsettings/dist'),('b1bffa63','@craft/web/assets/login/dist'),('b5d61e99','@craft/web/assets/edituser/dist'),('b77369bf','@craft/web/assets/iframeresizer/dist'),('b9b94dae','@craft/web/assets/craftsupport/dist'),('ba079f65','@craft/web/assets/htmx/dist'),('ba3e922a','@bower/jquery/dist'),('bbdd9a6a','@craft/web/assets/xregexp/dist'),('bc126008','@craft/web/assets/d3/dist'),('bc599fd0','@craft/web/assets/updateswidget/dist'),('bfde8dc2','@craft/web/assets/elementresizedetector/dist'),('c44ddfa2','@craft/web/assets/garnish/dist'),('ccb76c93','@craft/web/assets/vue/dist'),('ccef9ccc','@craft/web/assets/editsection/dist'),('ce0c10c1','@craft/web/assets/fileupload/dist'),('d077c66a','@craft/web/assets/jqueryui/dist'),('d0cbe33c','@craft/web/assets/picturefill/dist'),('d1113e35','@craft/web/assets/login/dist'),('d78bfb59','@craft/web/assets/clearcaches/dist'),('d7923b21','@craft/web/assets/feed/dist'),('d897b4c8','@craft/web/assets/velocity/dist'),('d91789f8','@craft/web/assets/craftsupport/dist'),('da90567c','@bower/jquery/dist'),('db735e3c','@craft/web/assets/xregexp/dist'),('dd00b67f','@craft/web/assets/jquerypayment/dist'),('dd53691d','@craft/web/assets/jquerytouchevents/dist'),('df704994','@craft/web/assets/elementresizedetector/dist'),('e15b6ca1','@craft/web/assets/picturefill/dist'),('e602b4bc','@craft/web/assets/feed/dist'),('e8870665','@craft/web/assets/craftsupport/dist'),('e9073b55','@craft/web/assets/velocity/dist'),('eae3d1a1','@craft/web/assets/xregexp/dist'),('ec9039e2','@craft/web/assets/jquerypayment/dist'),('ecc3e680','@craft/web/assets/jquerytouchevents/dist'),('ecffe8b5','@craft/web/assets/fabric/dist'),('fa71137','@craft/web/assets/utilities/dist'),('fba64f43','@craft/web/assets/plugins/dist'),('fcd57e8b','@craft/web/assets/utilities/dist'),('fd27e30e','@craft/web/assets/vue/dist'),('fd7f1351','@craft/web/assets/editsection/dist'),('ffef5621','@craft/web/assets/dashboard/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bugpwibtptdzoplwgmegboxeaxhmgnnnxfko` (`canonicalId`,`num`),
  KEY `fk_hvfzmydiihvaubhewakpmequmsyypigjhorh` (`creatorId`),
  CONSTRAINT `fk_hvfzmydiihvaubhewakpmequmsyypigjhorh` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_kjzpovkzxzlbxtcpgkomoiyfqujqdzljjajm` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,NULL,1,NULL),(2,4,NULL,1,NULL),(3,6,NULL,1,NULL),(4,6,8,2,NULL),(5,6,8,3,NULL),(6,11,8,1,NULL),(7,11,8,2,NULL),(8,11,8,3,NULL),(12,11,8,4,NULL),(13,11,8,5,NULL),(18,15,8,8,NULL),(19,15,8,9,NULL),(20,15,8,10,NULL),(21,15,8,11,NULL),(22,32,8,1,''),(23,15,8,12,'Applied “Draft 1”'),(24,15,8,13,NULL),(25,15,8,14,NULL),(26,15,8,15,''),(27,15,8,16,''),(28,11,8,6,NULL),(29,15,8,17,NULL),(30,32,8,2,'Applied “Draft 1”'),(31,32,8,3,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_nlepkgwyzblawkkgyvwgrccdtrybpdimtjij` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'slug',0,2,''),(1,'slug',0,1,''),(2,'title',0,2,' blog overview '),(2,'slug',0,2,' blog overview '),(2,'slug',0,1,' blog overview '),(2,'title',0,1,' blog overview '),(4,'title',0,2,' contact '),(4,'slug',0,2,' contact '),(4,'slug',0,1,' contact '),(4,'title',0,1,' contact '),(6,'title',0,2,' home '),(6,'slug',0,1,' home '),(8,'username',0,1,' snoeren mike gmail com '),(8,'firstname',0,1,''),(8,'fullname',0,1,''),(6,'slug',0,2,' home '),(6,'title',0,1,' home '),(11,'title',0,2,' contact '),(11,'title',0,1,' contact '),(15,'slug',0,2,' blog '),(15,'title',0,1,' blog '),(15,'title',0,2,' blog '),(15,'slug',0,1,' blog '),(11,'slug',0,2,' contact '),(11,'slug',0,1,' contact '),(32,'slug',0,1,' test '),(32,'title',0,1,' test '),(32,'slug',0,2,' test '),(32,'title',0,2,' test '),(42,'title',0,2,''),(41,'slug',0,2,' red '),(41,'title',0,2,' red '),(41,'title',0,1,' red '),(41,'slug',0,1,' red '),(42,'title',0,1,' orange '),(42,'slug',0,1,' orange '),(42,'slug',0,2,' temp rlkbmkkugefzugqmllafeupdhpludhvwzhoz '),(43,'slug',0,2,' temp yzfrajbuxtdojikfmbxkalvhmwjbtebvthtc '),(43,'title',0,1,' green '),(43,'title',0,2,''),(43,'slug',0,1,' green '),(44,'slug',0,2,' temp nrlpvotkjtsvqbwvxsagzhdgpjdlpshoqnpi '),(44,'slug',0,1,' blue '),(44,'title',0,1,' blue '),(44,'title',0,2,''),(45,'slug',0,2,' temp lwuazyokhtumlqhpcjvpfxiufksemwyjvfyw '),(45,'slug',0,1,' purple '),(45,'title',0,2,''),(45,'title',0,1,' purple '),(46,'slug',0,2,' temp impxxmmxftbpdgsoqsyqzgfyadwtfnuwzmca '),(46,'title',0,1,' purple '),(46,'slug',0,1,' purple '),(46,'title',0,2,''),(47,'slug',0,2,' temp dfdmnnbssydvobffmdhyiuxkpgschxdcfjcc '),(47,'title',0,1,' pink '),(47,'title',0,2,''),(47,'slug',0,1,' pink '),(8,'lastname',0,1,''),(8,'email',0,1,' snoeren mike gmail com '),(8,'slug',0,1,''),(52,'slug',0,1,' blog '),(52,'slug',0,2,' blog '),(52,'title',0,2,' blog '),(52,'title',0,1,' blog '),(54,'title',0,2,' test '),(54,'slug',0,1,' temp zemrplkgrdpnvvztyzghociokbfdbmiyzvur '),(54,'title',0,1,' test '),(54,'slug',0,2,' test ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'end',
  `previewTargets` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xusxvruvwzpkxvlsrmzlhqbqzwttjqabwcjp` (`handle`),
  KEY `idx_jpzjoklumixvpyupeurcdiaoecevzgxuzenz` (`name`),
  KEY `idx_ztriqrqjqxfanzutakpgrdehkdipknpjkuog` (`structureId`),
  KEY `idx_mgqtgaimlqxdximqzsdrhffikupukjloowoe` (`dateDeleted`),
  CONSTRAINT `fk_idckjrlitjowoxqdbgwlvxgoexhvnxwczgdz` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Blog','blog','channel',1,'all','end',NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:54','f1b92217-9f3d-4b80-b798-a6f08ef1189a'),(2,NULL,'Blog Overview','blogOverview','single',1,'all','end',NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:42','dcab3086-dee3-497f-9073-49908ef6d388'),(3,NULL,'Contact','contact','single',1,'all','end',NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35','2022-04-29 18:40:47','3306e5be-ccfc-4d7d-9390-381647684124'),(4,NULL,'Home','home','single',1,'all','end',NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'93d532cc-c2dd-4fdc-b7cb-d043ca7f6b68'),(5,NULL,'Pages','pages','channel',1,'all','end',NULL,'2022-02-14 21:25:35','2022-02-14 21:25:35',NULL,'1fa133fd-47b8-4acc-857d-b9677a729349'),(6,NULL,'Contact','contact','single',1,'all','end',NULL,'2022-04-29 18:43:18','2022-04-29 18:43:18',NULL,'7043c508-fdf8-4bf1-a9d9-cdfa67ca6cc2'),(7,NULL,'Blog - Items','blogItems','channel',1,'all','end',NULL,'2022-04-29 19:05:46','2022-05-12 17:57:02',NULL,'1c008561-0013-4b4d-b04a-f51a038c5a20'),(8,NULL,'Blog','blog','single',1,'all','end',NULL,'2022-04-29 20:00:58','2022-05-12 17:57:29',NULL,'9e3d67ef-15cc-4352-b1c0-1f9a84b0f10d');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `template` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iulefwrszpsrvawxvyzhwhdkbagtndjnorpz` (`sectionId`,`siteId`),
  KEY `idx_dplofgtvkucfemfyzbqrfrubzuqmppztrlkt` (`siteId`),
  CONSTRAINT `fk_cshotgivntghxjjqluuxswpoaxeclagjyvwg` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_snwzypaiztmlqukjnwavnzoktczoanatjshg` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'blog/{slug}','_blog/_entry',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','ae599853-7984-4beb-ad12-cc84568cf353'),(2,1,2,1,'blog/{slug}','_blog/_entry',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','37c07c3d-429b-4882-b9b4-0d9244777ed1'),(3,2,1,1,'blog','_blog/index',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','1d11a0c9-61f7-41a6-81c0-a540b92b62b3'),(4,2,2,1,'blog','_blog/index',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','b0e813d4-b185-4898-97b3-6a94ed60f072'),(5,3,1,1,'contact','_contact/index',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','34519aba-67e5-45ea-85cd-537a84ca9454'),(6,3,2,1,'contact','_contact/index',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','a6da76c6-73da-4071-b25b-503c2d44ca33'),(7,4,1,1,'__home__','index',1,'2022-02-14 21:25:35','2022-04-29 18:41:54','207d09d6-e24a-49bd-aae3-f53e074a95b1'),(8,4,2,1,'__home__','index',1,'2022-02-14 21:25:35','2022-04-29 18:41:54','a9cff370-1ea6-44fa-abbd-7c46ae7d7dea'),(9,5,1,1,'{slug}','_pages',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','ebd29d2f-f777-4d6e-a0ae-33faa03d3e1d'),(10,5,2,1,'{slug}','_pages',1,'2022-02-14 21:25:35','2022-02-14 21:25:35','f85e7c17-1686-4c8f-ac99-cc1b770b0961'),(11,6,1,1,'{slug}','_contact/index.twig',1,'2022-04-29 18:43:18','2022-05-12 18:14:40','36f40dd3-e6e4-49d3-8600-5b13202858dc'),(12,6,2,1,'{slug}','_contact/index.twig',1,'2022-04-29 18:43:18','2022-05-12 18:14:40','e81efc7e-7965-4a9e-8336-f4c2ad1ebbd0'),(13,7,1,1,'{{ craft.entries.section(\'blog\').one.slug }}/{slug}','_blog/entry',1,'2022-04-29 19:05:46','2022-05-22 13:13:52','d2635f3a-8507-40de-a054-ece43199b618'),(14,7,2,1,'{{ craft.entries.section(\'blog\').one.slug }}/{slug}','_blog/entry',1,'2022-04-29 19:05:46','2022-05-12 18:01:18','1eb713e9-860a-4cd5-85ef-d283a14da348'),(15,8,1,1,'{slug}','_blog/index.twig',1,'2022-04-29 20:00:58','2022-05-12 17:45:34','8a0bd019-4118-4a9a-99c5-5dea8637c13d'),(16,8,2,1,'{slug}','_blog/index.twig',1,'2022-04-29 20:00:58','2022-05-12 17:45:34','7f6279bf-09d9-4c72-97de-e463ea5e9934');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_redirects`
--

DROP TABLE IF EXISTS `seo_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_redirects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `to` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('301','302') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `siteId` int DEFAULT NULL,
  `order` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_redirects`
--

LOCK TABLES `seo_redirects` WRITE;
/*!40000 ALTER TABLE `seo_redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_sitemap`
--

DROP TABLE IF EXISTS `seo_sitemap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_sitemap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group` enum('sections','categories','productTypes','customUrls') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `frequency` enum('always','hourly','daily','weekly','monthly','yearly','never') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `priority` float NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_sitemap`
--

LOCK TABLES `seo_sitemap` WRITE;
/*!40000 ALTER TABLE `seo_sitemap` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_sitemap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xlffivfklkvnqfggkzowcqheutsajbosfflp` (`uid`),
  KEY `idx_dfwcxnkjehoocstxhxootjpilcmrfjlywjty` (`token`),
  KEY `idx_llxbndofdkqiqteenznaetxlnczbvnxcmnmu` (`dateUpdated`),
  KEY `idx_fgontszgrsbajypwfpncbjnfcgnpvwdelcui` (`userId`),
  CONSTRAINT `fk_dfcwfsypzveekcxkgiqyxllwogmhbqaqtcpf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,8,'g5xU2rZzzkgrYpZ8FGgA8LgtZMXT3abT0ocxvETW48VkdoFKZIQopjj_ijyKBShRE50LoWNf8l4xH1N-LcpG2OkVMlKXPtp94RDs','2022-02-22 22:44:03','2022-02-22 22:45:05','7f3275b3-6807-4c3a-b288-0eac3e340b44'),(2,8,'UnBgV-cRLXWnV_xLnH8zbDEivH5fv2dWxQTIN9ewTNrbCxvhl-6U_P8jc50fC7c-7qiITFFhwfegDC7CjBGj5zVAflMdRdeHk--v','2022-04-29 18:37:57','2022-05-04 07:36:46','784a0de4-cf7d-42f1-a0ef-1622150f0a63'),(3,8,'ba_sWFfoTAR_NfKlMyCD5VN0Vhtj8--am7JAvQDN_Bkp-Gpm7ePc25k5Wa1qdozEv6pT13KZPH6uQoVzp6wQJSpfvll_9MnD60pU','2022-05-09 08:29:10','2022-05-11 10:14:00','bec4ba91-2d2c-444a-bcc1-c9ea0f643b9d'),(4,8,'hj4mNDNTHuEroJyb6CB2p7YLHuBrF_Va5iSTHf8Iz3PKvE66TibaOmtuGYC5beffNGmFj5XCZJtvOv9o6qXRuC861Da1utXLuI-6','2022-05-11 10:14:01','2022-05-11 16:35:59','37cec322-24ac-4ee6-a7fe-52e7e97318e5'),(5,8,'1B3iMSNgqjQ5caiygyNlArTzuRXlTjWNA70pIki8N-m7M5QZcxeZJ0MnhdfNBCKw8VHtIxn3vqcylxoQg8T3cTABWtcp0YxScn1u','2022-05-11 16:38:38','2022-05-11 16:46:39','5f7286d5-3e1a-400d-a9c1-73e48bf160a0'),(7,8,'TzgONcFTGBkubgm7bMSULO5m_G8CcPueq7YnsTF9AjxAGD6ssCSGRtsQMY_qtpcrEMPDTR9D-DzJZFHszrT8Ekmt1ZtBtGaKDSdj','2022-05-12 17:34:40','2022-05-16 09:53:22','cd6be5bf-53b8-40b6-9322-de968b559826'),(8,8,'YS7HNn3E1al2G-iL0sPVMm6Q6A55BGCC7mi_bcEo3E7o0SPa-RpfndJy17tTsOxRFNevtfbHjXjlqSyFZqVijtYta18qvvilGFSN','2022-05-22 12:13:29','2022-05-23 20:33:18','146be888-34d0-47bd-83a9-5fe67a9bbb75');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yfbrdtqnwxihemgqvkqmsnkvvqikjgyauzpe` (`userId`,`message`),
  CONSTRAINT `fk_flofnkkgmczmicqnijncgljmkyvweroecgtn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eccvxyhrzocdmvmdftehcigsigsdwqqaltwg` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'$CRAFT_SITE_NAME','2022-02-14 21:25:33','2022-05-11 16:47:24',NULL,'fd05975e-1963-4ddd-8f7b-57678dbe0ac6');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'true',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `language` varchar(12) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yrdzjfqwddnvimstyesvfdudwwheybqwrhaq` (`dateDeleted`),
  KEY `idx_apaujtrdufnzrkstqjzcaspvctwfuwbikvkx` (`handle`),
  KEY `idx_jrwigirkyzjtasrkkdatbegdfazoientexnm` (`sortOrder`),
  KEY `fk_cftgayawlicsiokzdlgyihsgmzcciscmnfju` (`groupId`),
  CONSTRAINT `fk_cftgayawlicsiokzdlgyihsgmzcciscmnfju` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','English','English','en',1,'@web',1,'2022-02-14 21:25:33','2022-05-11 16:47:41',NULL,'4d8ac26f-0eed-4e84-8f0f-fb59450142e3'),(2,1,0,'1','Dutch','dutch','nl',1,'@web_nl',2,'2022-02-14 21:25:33','2022-05-11 16:48:03',NULL,'f5399107-84c7-4af5-8764-8c333d1b9ebc');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_psdxosoxlsdgyyvjwjkfzbodlvwcpnxyjgce` (`structureId`,`elementId`),
  KEY `idx_dxtrwhhcdefhufyiasacxcfcntrkspiqovhd` (`root`),
  KEY `idx_ewspcvqrzndkimcghntrvylpddolzqykumby` (`lft`),
  KEY `idx_vxkufnbyrnfepyqyeolwfhqmlcodjdfaamtu` (`rgt`),
  KEY `idx_qgjxqgnuidcljhfwbypqcaqgbgwtqpfzedrh` (`level`),
  KEY `idx_ukinohmvmrjrfgmlzdlapwznlyqqqsdznyic` (`elementId`),
  CONSTRAINT `fk_oqldtksjkhxqwjuaahjvakntilnajmtyjzzx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_renlduqlrmirqyophfilencjhtffwhafwrvy` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,14,0,'2022-05-13 17:59:58','2022-05-13 18:02:00','69b640d9-4164-4fb9-9a79-42bf2a3ccb23'),(2,1,41,1,2,3,1,'2022-05-13 17:59:58','2022-05-13 17:59:58','7a0a9d4e-54d3-4cfa-b4f2-1cadcaffb4e5'),(3,1,42,1,4,5,1,'2022-05-13 18:00:36','2022-05-13 18:00:36','f0de4b01-5b96-400d-be06-c3b06a5439e8'),(4,1,43,1,6,7,1,'2022-05-13 18:00:46','2022-05-13 18:00:46','b5d0ae86-d30d-450c-9b9b-0b1f991c1a22'),(5,1,44,1,8,9,1,'2022-05-13 18:00:57','2022-05-13 18:00:57','9a9954da-b99a-4067-9751-9475aa1de5d4'),(6,1,45,1,10,11,1,'2022-05-13 18:01:11','2022-05-13 18:01:11','5dcb5364-4fb2-4560-9ca8-4c16796f4710'),(8,1,47,1,12,13,1,'2022-05-13 18:01:38','2022-05-13 18:02:00','4c1c28b3-2109-4eed-8cf5-4d3deed4d7a1');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ecgxyjzuaepmzzxdqiatdbjfnghqfxegzkcf` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,1,'2022-02-14 21:25:34','2022-02-14 21:25:34',NULL,'4641dbd1-76ee-44b0-ab32-bb5f902609b0');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supertableblocks`
--

DROP TABLE IF EXISTS `supertableblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supertableblocks` (
  `id` int NOT NULL,
  `ownerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vqvpxrgdkprhtpywzbrhszylvziozbuqsinx` (`ownerId`),
  KEY `idx_avgnwkhoyrsgwujdpskkafdgeskujnzehrcu` (`fieldId`),
  KEY `idx_ouqhkbxylmiatlfglqxlfpodegidxdaqlmme` (`typeId`),
  KEY `idx_icbmyjmzkwtzepiuwnsxfpmgnvtjjpkktcop` (`sortOrder`),
  CONSTRAINT `fk_eawotznzdzpzjrskvxepdaihlhfejebkcisw` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_njigwdpenzpvzceulkzxbsegfvucdmsohzhw` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rptrsulhrxjzimhmptkpvlgazijvuinddiqj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zkfghifzpmpaxrfybokordyakmswavqxegzx` FOREIGN KEY (`typeId`) REFERENCES `supertableblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supertableblocks`
--

LOCK TABLES `supertableblocks` WRITE;
/*!40000 ALTER TABLE `supertableblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `supertableblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supertableblocktypes`
--

DROP TABLE IF EXISTS `supertableblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supertableblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_afydlqgyyipclcnulwxyemcqytswugzgekxs` (`fieldId`),
  KEY `idx_pyinjoaznoslwhntruzsozqkjeinwapfkolt` (`fieldLayoutId`),
  CONSTRAINT `fk_kuovvbkeijcuikdhagdiosnmiitdjaggsbzt` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ylhqjyzdaiobyzwbywqavfgyrkltwpxqknth` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supertableblocktypes`
--

LOCK TABLES `supertableblocktypes` WRITE;
/*!40000 ALTER TABLE `supertableblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `supertableblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `subject` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gzkvoijtaykfcskmzvveahbbxcyfxjyghiwb` (`key`,`language`),
  KEY `idx_cjoyuijxopphpualdbbdpjbulivzdubmhkpk` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cfgjvhkzwzmssbbtpaqwtkziumdgdhdcyvrp` (`name`),
  KEY `idx_itgyhxtkguugzizedqjrkviodaxerfzmbbeu` (`handle`),
  KEY `idx_scpxmvgnphnhruzjioljcugvskodwhlsijyz` (`dateDeleted`),
  KEY `fk_krkslmkxkonrlswtvffmlcmqgtkhcmvvseeb` (`fieldLayoutId`),
  CONSTRAINT `fk_krkslmkxkonrlswtvffmlcmqgtkhcmvvseeb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lzsivxjboqkyojyhohdtfhahfingzvdklwgr` (`groupId`),
  CONSTRAINT `fk_hykthisqamywkkmuwyjmsnctgmpvlwsvijdi` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_inpaxykyaxbfpbcldnrebunnvaustppujtvd` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `route` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ihcppyrwdwvhzyrgnqejkjknjgmmdyfxdoez` (`token`),
  KEY `idx_ymsvbmevfftfmexxipjbcogebasqiwbzigtq` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,'NCLLwMRAq9avaTYTM52sWe1WjONf7MF8','[\"preview/preview\",{\"elementType\":\"craft\\\\elements\\\\Entry\",\"canonicalId\":15,\"siteId\":2,\"draftId\":null,\"revisionId\":null,\"userId\":8}]',NULL,NULL,'2022-05-13 17:39:39','2022-05-12 17:39:39','2022-05-12 17:39:39','177a6feb-38d5-4017-b4b0-8a023421812a');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jmxwdicuwimrnrgbkymfztogkvbkhomarmll` (`handle`),
  KEY `idx_vxixkdljoerttvdhadbistgvpjvfasfhqwzb` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_azpvvijbpfwsynlustmdjynpsaizerzzuobh` (`groupId`,`userId`),
  KEY `idx_eqnwlzxakflzwyoiqyhuiicykslkuziqdzvh` (`userId`),
  CONSTRAINT `fk_pcvpfugurdbfvgrcgqcbwyreppqccurkxosm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yrulxgbdbenkmqiogcycdbtkpztpyyfomcrh` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xhpxumrtacwjyffmjupcuijiwrcddpvcuspf` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tjngrdoefpwrcvmgefpzgjqyotziymbeksye` (`permissionId`,`groupId`),
  KEY `idx_clpavzrtgycjshjkaybqkhatfjwaufirjmho` (`groupId`),
  CONSTRAINT `fk_ecnxibpmjdrqpjoqhnijthwiivwjjxnxvtqr` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lisrwltfpetuamdjrtbxedfdbyzbckalbuop` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_chysdzoeoffxqqgqtwflluoepgfowtadwzvy` (`permissionId`,`userId`),
  KEY `idx_gcymxaexftkwdylvpvhsodqhlyzpqljnzpbh` (`userId`),
  CONSTRAINT `fk_fkeomwgbodjkktomdfefyywhtjfxpumnrtmj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wjffqzzqmcleejmzddgfzhkzdohmnlgnswpp` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_olyuxyjjwvzmlrjlhrmwyqdyspoqdjphqsdy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (8,'{\"language\":\"en\",\"locale\":null,\"weekStartDay\":\"1\",\"alwaysShowFocusRings\":false,\"useShapes\":false,\"underlineLinks\":false,\"showFieldHandles\":true,\"enableDebugToolbarForSite\":true,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `photoId` int DEFAULT NULL,
  `firstName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eavwzpuaubehvehnirizdfdavhawqbqepfkb` (`verificationCode`),
  KEY `idx_qdobdnxqilupxvgsxbplskaokethrnwwadae` (`email`),
  KEY `idx_guppfyogwecwoygkjtkxelqoupcokvrjpzbx` (`username`),
  KEY `fk_vbzdmyfjnexamtefgchvaostmozjtumkbyph` (`photoId`),
  KEY `idx_sumfwddzpaztmucngofxbfivivbvsfbhaxfb` (`active`),
  KEY `idx_rfupltyhqfjqhardtapmzaepdcbevraylfsx` (`locked`),
  KEY `idx_vogmmyjpdnqyhbgklkigqukkgmfsvehqnehr` (`pending`),
  KEY `idx_hwfvorbmvngtprfblglusaighjcixjwgnauf` (`suspended`),
  CONSTRAINT `fk_vbzdmyfjnexamtefgchvaostmozjtumkbyph` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wqvhklmqabrpsdlcgiloylecdmnmxuzcyisa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (8,'snoeren.mike@gmail.com','',NULL,NULL,NULL,'snoeren.mike@gmail.com','$2y$13$/QaGQYjv4WpQQqN7IM85S.5eH1gia2DDy3KQmqLmPbZLyY9zttVGi',1,1,0,0,0,'2022-05-22 12:13:29',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2022-02-14 21:25:37','2022-02-14 21:25:37','2022-05-22 12:13:29');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_madsgojpnbizxhlmbpzjnbauayfghsbuijmp` (`name`,`parentId`,`volumeId`),
  KEY `idx_fzixkstbttkwrwrvyvdicbxukrdsnkmpfkif` (`parentId`),
  KEY `idx_xcwrzqvlefxqfbmwxbalqguhwnvlqxuqcici` (`volumeId`),
  CONSTRAINT `fk_coqhlkbsmwlxqaieoexthsmaczsjjvnfkumj` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_txelcaazllgdflvznqvxucfepzfsmixcldmq` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Main',NULL,'2022-02-14 21:25:35','2022-05-11 16:49:47','443cbac2-9a8a-479b-8977-b31cdbbcbe9a');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fs` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `transformFs` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `transformSubpath` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `titleTranslationMethod` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oqpcjzllkyyjtolhgliypelcdaghctjgwrce` (`name`),
  KEY `idx_lhvkqezujbbwbpkubtttdghwaedfpsziumqr` (`handle`),
  KEY `idx_mqwtamisxndwvhtwjlnhvxudglfbublfzlxa` (`fieldLayoutId`),
  KEY `idx_hkriiulyrrazfrqrfalasnoxzqsoflgxjaij` (`dateDeleted`),
  CONSTRAINT `fk_jnluotiioylgxvwxnterppjcxodyoweyolca` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,3,'Main','main','main','','_transforms','site',NULL,1,'2022-02-14 21:25:35','2022-05-11 16:49:47',NULL,'5f8ef687-1fd6-4714-9fe5-0e0f7900dcaf');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fzxtkjvqvzysqsqdksmmqsytfcevsnhtnapn` (`userId`),
  CONSTRAINT `fk_hzxtzmjkgufbupsihcvjxmetlofrlqngzckr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,8,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2022-02-14 21:25:40','2022-02-14 21:25:40','ae899523-fdd2-4c89-834a-fe8097b58d84'),(2,8,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2022-02-14 21:25:40','2022-02-14 21:25:40','a1646059-a517-4acf-884d-fc9785726f6b'),(3,8,'craft\\widgets\\Updates',3,NULL,'[]',1,'2022-02-14 21:25:40','2022-02-14 21:25:40','afab204a-07b9-45a8-890e-8b65bdcdad00'),(4,8,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2022-02-14 21:25:40','2022-02-14 21:25:40','08deb94a-854b-4d57-b5c9-4e12c33f8f27');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-25 12:07:02
